/* ==========================================================================
   PANNACOTTACLUB — carte réelle OpenStreetMap (Leaflet), 100 % autonome
   --------------------------------------------------------------------------
   Une VRAIE carte (rues, plage, mer) pour suivre le livreur en temps réel.

   Choix technique : OpenStreetMap + Leaflet, hébergés dans le site
   (assets/vendor/leaflet/). Pourquoi pas Google ? Google exige une clé API
   facturée, alors qu'OSM est gratuit et sans inscription — et la qualité
   est parfaite pour un suivi de livraison.

   Repères géographiques exacts du club :
     · Poste de secours 1 : 49.289616, -0.139386
     · Poste de secours 2 : 49°17'29.8"N 0°07'43.1"W  (49.291611, -0.128639)

   Comportement :
     · épingles maison : V (vous, bleu) · L (livreur, bleu nuit)
     · la zone de livraison est entourée d'un cercle
     · le livreur GLISSE en douceur à chaque nouvelle position (aucun saut)
     · la carte suit la course : recentrage doux si le livreur sort du cadre
     · boutons zoom + « tout afficher », bandeau d'infos (distance, heure…)
     · l'attribution OpenStreetMap est affichée (obligatoire et méritée !)
   ========================================================================== */
import { distanceLabel, BASE } from './core.js';

/* Ouvre l'application de cartes du téléphone (itinéraire). */
export const mapsLink = (pos) =>
  `https://www.google.com/maps/dir/?api=1&destination=${pos.lat},${pos.lng}&travelmode=walking`;

export const geoLink = (pos) => `geo:${pos.lat},${pos.lng}?q=${pos.lat},${pos.lng}`;

/* ------------------------------------------------------- repères exacts */
const POSTE1 = { lat: 49.289616, lng: -0.139386 };
const POSTE2 = { lat: 49.291611, lng: -0.128639 };   /* 49°17'29.8"N 0°07'43.1"W */
const MILIEU = { lat: (POSTE1.lat + POSTE2.lat) / 2, lng: (POSTE1.lng + POSTE2.lng) / 2 };

/* Les 11 accès/escaliers de la digue, répartis régulièrement entre le
   poste 1 (sud-ouest) et le poste 2 (nord-est), le long de la promenade
   Marcel Proust. Chaque panneau QR porte ce numéro : quand un client le
   scanne, le site sait immédiatement où il se trouve — sans GPS. */
export const ACCES_DIGUE = Array.from({ length: 11 }, (_, i) => {
  const f = i / 10;
  return {
    n: i + 1,
    lat: Number((POSTE1.lat + (POSTE2.lat - POSTE1.lat) * f).toFixed(6)),
    lng: Number((POSTE1.lng + (POSTE2.lng - POSTE1.lng) * f).toFixed(6)),
  };
});
const RAYON_PAR_DEFAUT = 700;   /* mètres : couvre les deux postes + le sable */

let CONFIG = { zone: null };

/** Conservé pour compatibilité avec app.js (zone transmise par /api/config). */
export function configureMap({ zone = null } = {}) {
  CONFIG = { zone: zone || null };
  return CONFIG;
}

const nb = (v) => (Number.isFinite(Number(v)) ? Number(v) : null);

/* ------------------------------------------------------ chargement Leaflet */
let promesseLeaflet = null;

function chargerLeaflet() {
  if (window.L) return Promise.resolve(window.L);
  if (!promesseLeaflet) {
    promesseLeaflet = new Promise((resoudre, rejeter) => {
      const css = document.createElement('link');
      css.rel = 'stylesheet';
      css.href = `${BASE}assets/vendor/leaflet/leaflet.css`;
      document.head.appendChild(css);
      const script = document.createElement('script');
      script.src = `${BASE}assets/vendor/leaflet/leaflet.js`;
      script.onload = () => (window.L ? resoudre(window.L) : rejeter(new Error('leaflet-absent')));
      script.onerror = () => { promesseLeaflet = null; rejeter(new Error('leaflet-injoignable')); };
      document.head.appendChild(script);
      setTimeout(() => { if (window.L) resoudre(window.L); }, 8000);
    });
  }
  return promesseLeaflet;
}

/* ============================================================== création === */
/**
 * Crée la carte réelle dans le conteneur.
 * @param {HTMLElement} el conteneur (.map)
 * @param {{center?:{lat,lng}, zoom?:number, zone?:object}} options
 */
export function createMap(el, { center = null, zoom = 15, zone = null } = {}) {
  if (!el) return null;

  const laZone = zone || CONFIG.zone || null;
  const centreZone = (nb(laZone?.lat) != null && nb(laZone?.lng) != null)
    ? { lat: Number(laZone.lat), lng: Number(laZone.lng) }
    : MILIEU;
  const rayonZone = nb(laZone?.radius) || RAYON_PAR_DEFAUT;

  const etat = {
    el, mode: 'osm', pret: false, erreur: '', client: null, livreur: null,
    livreurs: new Map(), destruction: false, maj: 0, minuteur: null,
    carte: null, suivre: true,
  };

  /* La légende éventuellement déjà présente (« Vous / Votre livreur ») est
     conservée et reposée par-dessus la carte. */
  const dejaLa = [...el.children];
  el.classList.add('pcmap', 'pcosm');
  el.innerHTML = `
    <div class="pcosm-cadre">
      <div class="pcosm-canvas"></div>
      <div class="pcmap-charge">Chargement du plan…</div>
    </div>
    <div class="pcmap-controles">
      <button type="button" class="pcmap-btn" data-zoom="1" aria-label="Zoomer">+</button>
      <button type="button" class="pcmap-btn" data-zoom="-1" aria-label="Dézoomer">−</button>
      <button type="button" class="pcmap-btn pcmap-btn-large" data-action="fit" aria-label="Tout afficher" title="Tout afficher">⤢</button>
      <button type="button" class="pcmap-btn pcmap-btn-large" data-action="suivre" aria-label="Suivre le livreur" title="Recentrer sur le livreur">🎯</button>
    </div>
    <div class="pcmap-bandeau">
      <span class="pcmap-etat">Chargement de la carte…</span>
      <a class="pcmap-lien" data-role="position" href="#" target="_blank" rel="noopener">Position</a>
      <a class="pcmap-lien" data-role="itineraire" href="#" target="_blank" rel="noopener" hidden>Itinéraire</a>
    </div>`;
  const cadreEl = el.querySelector('.pcosm-cadre');
  for (const node of dejaLa) cadreEl.appendChild(node);   /* légende conservée */

  const etatEl = el.querySelector('.pcmap-etat');
  const chargeEl = el.querySelector('.pcmap-charge');
  const lienEl = el.querySelector('[data-role="position"]');
  const lienItineraire = el.querySelector('[data-role="itineraire"]');

  /* ------------------------------------------------------------- épingles */
  const fabriqueEpingles = (L) => ({
    point: (lettre, couleur) => L.divIcon({
      className: 'pcmarker pcsuite',
      html: `<span class="pcmarker-point" style="background:${couleur}">${lettre}</span>`,
      iconSize: [36, 36], iconAnchor: [18, 18],
    }),
    poste: (num) => L.divIcon({
      className: 'pcmarker',
      html: `<span class="pcposte-pt">${num}</span>`,
      iconSize: [30, 30], iconAnchor: [15, 15],
    }),
  });

  /* --------------------------------------------------------------- démarrage */
  chargerLeaflet().then((L) => {
    if (etat.destruction) return;
    const carte = L.map(el.querySelector('.pcosm-canvas'), {
      zoomControl: false,              /* nos propres boutons, plus jolis */
      attributionControl: true,
      scrollWheelZoom: !L.Browser.touch,   /* molette sur PC, pas de zoom accidentel au doigt */
      tap: true,
    }).setView(centreZone, Math.max(3, Math.min(19, Number(zoom) || 15)));

    /* Fond de carte ENTIÈREMENT hébergé dans le site (assets/map/cabourg.json,
       véritable extrait d'OpenStreetMap : mer, plage, rues, bâtiments).
       Aucune requête externe : conforme à la sécurité de l'hébergeur (CSP)
       et ça fonctionne même sans réseau, sur le sable. */
    carte.attributionControl.addAttribution('Données © OpenStreetMap');
    fetch(`${BASE}assets/map/cabourg.json`).then((r) => r.json()).then((geo) => {
      if (etat.destruction || !etat.carte) return;
      const STYLES = {
        mer:      { fillColor: '#A9CCEF', fillOpacity: 1, stroke: false },
        plage:    { fillColor: '#F3E4BC', fillOpacity: 1, stroke: false },
        eau:      { fillColor: '#A9CCEF', fillOpacity: 1, stroke: false },
        vert:     { fillColor: '#CFE9C8', fillOpacity: 1, stroke: false },
        batiment: { fillColor: '#E2E6FB', fillOpacity: 1, color: '#C7CDF2', weight: 1 },
        route:    { color: '#FFFFFF', weight: 3.5, opacity: 1 },
        chemin:   { color: '#FFFFFF', weight: 2.5, opacity: .9, dashArray: '1 6', lineCap: 'round' },
      };
      L.geoJSON(geo, {
        interactive: false,
        smoothFactor: 0.6,
        style: (f) => STYLES[f.properties?.kind] || STYLES.vert,
      }).addTo(carte);
      etat.fond = true;
    }).catch(() => {
      if (!etat.destruction && etatEl) etatEl.textContent = 'Plan détaillé indisponible — épingles et zone affichées.';
    });

    /* Zone de livraison : cercle bleu. */
    L.circle([centreZone.lat, centreZone.lng], {
      radius: rayonZone,
      color: '#060CD4', weight: 2, opacity: 0.55, fillColor: '#060CD4', fillOpacity: 0.06,
    }).addTo(carte);

    /* Les deux postes de secours, positions exactes, toujours visibles. */
    const ep = fabriqueEpingles(L);
    for (const [num, p] of [['1', POSTE1], ['2', POSTE2]]) {
      L.marker([p.lat, p.lng], { icon: ep.poste(num), zIndexOffset: 100 })
        .addTo(carte)
        .bindTooltip(`Poste de secours ${num}`, {
          permanent: true, direction: 'bottom', offset: [0, 12], className: 'pcposte-tip',
        });
    }

    etat.carte = carte;
    etat.L = L;
    etat.pret = true;
    chargeEl.hidden = true;
    carte.on('dragstart zoomstart', () => { etat.suivre = false; });
    el.querySelector('[data-action="suivre"]').addEventListener('click', () => {
      etat.suivre = true;
      const cible = etat.livreur || etat.client || centreZone;
      carte.setView([cible.lat, cible.lng], Math.max(carte.getZoom(), 16), { animate: true });
    });
    peindre();
    cadrer();
  }).catch((err) => {
    etat.erreur = String(err.message || err);
    chargeEl.textContent = 'Carte indisponible (hors connexion).';
    etatEl.textContent = 'Carte indisponible hors connexion — position exacte ci-dessous.';
    if (etat.livreur || etat.client) lienEl.href = mapsLink(etat.livreur || etat.client);
  });

  /* ------------------------------------------------------------- épingles */
  const poserOuBouger = (cle, pos, { lettre, couleur, titre }) => {
    const L = etat.L;
    if (!L || !etat.carte) return;
    const q = [Number(pos.lat), Number(pos.lng)];
    if (!etat.epingles) etat.epingles = new Map();
    let m = etat.epingles.get(cle);
    if (!m) {
      m = L.marker(q, {
        icon: fabriqueEpingles(L).point(lettre, couleur),
        title: titre || '',
        zIndexOffset: 500, keyboard: false,
      }).addTo(etat.carte);
      etat.epingles.set(cle, m);
    } else {
      m.setLatLng(q);           /* la classe .pcsuite anime le glissement */
    }
  };

  const retirer = (cle) => {
    const m = etat.epingles?.get(cle);
    if (m) { etat.carte.removeLayer(m); etat.epingles.delete(cle); }
  };

  /* --------------------------------------------------------------- bandeau */
  const ilYA = (ms) => {
    const sec = Math.round((Date.now() - ms) / 1000);
    if (sec < 5) return "à l'instant";
    if (sec < 60) return `il y a ${sec} s`;
    return `il y a ${Math.round(sec / 60)} min`;
  };

  function majBandeau() {
    const l = etat.livreur;
    const c = etat.client;
    const bouts = [];
    if (l && c) {
      const R = 6371000;
      const dLat = ((c.lat - l.lat) * Math.PI) / 180;
      const dLng = ((c.lng - l.lng) * Math.PI) / 180;
      const h = Math.sin(dLat / 2) ** 2
        + Math.cos((l.lat * Math.PI) / 180) * Math.cos((c.lat * Math.PI) / 180) * Math.sin(dLng / 2) ** 2;
      bouts.push(`Livreur à ${distanceLabel(2 * R * Math.asin(Math.sqrt(h)))}`);
    }
    const ref = l || c;
    if (ref) {
      bouts.push(`position exacte ${ref.lat.toFixed(5)}, ${ref.lng.toFixed(5)}`);
      if (ref.at) bouts.push(`relevée ${ilYA(ref.at)}`);
      if (nb(ref.accuracy) && Number(ref.accuracy) > 0) bouts.push(`précision ± ${Math.round(ref.accuracy)} m`);
    } else {
      bouts.push('En attente d’une course — poste 1 et poste 2 indiqués sur la carte');
    }
    etatEl.textContent = bouts.join(' · ');
  }

  function peindre() {
    majBandeau();
    if (!etat.carte) return;
    if (etat.client) poserOuBouger('client', etat.client, { lettre: 'V', couleur: '#060CD4', titre: 'Vous' });
    else retirer('client');
    for (const [id, l] of etat.livreurs) {
      poserOuBouger(`livreur:${id}`, l, { lettre: 'L', couleur: '#090A33', titre: l.titre || 'Livreur' });
    }
    for (const cle of [...(etat.epingles?.keys() || [])]) {
      if (cle.startsWith('livreur:') && !etat.livreurs.has(cle.slice(8))) retirer(cle);
    }
    /* La carte suit la course : si le livreur sort du cadre, on le ramène doucement. */
    if (etat.suivre && etat.livreur && etat.carte) {
      const b = etat.carte.getBounds().pad(-0.12);
      const p = etat.livreur;
      if (!b.contains([p.lat, p.lng])) {
        etat.carte.panTo([p.lat, p.lng], { animate: true, duration: 0.8 });
      }
    }
    const c = etat.client;
    lienItineraire.hidden = !(c && etat.livreur);
    if (c && etat.livreur) {
      lienItineraire.href = `https://www.google.com/maps/dir/?api=1&origin=${etat.livreur.lat},${etat.livreur.lng}&destination=${c.lat},${c.lng}&travelmode=walking`;
    }
    const ref = etat.livreur || etat.client;
    if (ref) lienEl.href = mapsLink(ref);
  }

  function cadrer() {
    if (!etat.carte) return;
    const L = etat.L;
    const points = [etat.client, ...etat.livreurs.values(), POSTE1, POSTE2].filter(Boolean);
    if (points.length > 1) {
      etat.carte.fitBounds(L.latLngBounds(points.map((p) => [p.lat, p.lng])), { padding: [36, 36], maxZoom: 17 });
    } else {
      etat.carte.setView([centreZone.lat, centreZone.lng], 15);
    }
  }

  /* -------------------------------------------------------------- contrôles */
  const bouton = (sel, fn) => el.querySelector(sel)?.addEventListener('click', fn);
  bouton('[data-zoom="1"]', () => etat.carte?.zoomIn());
  bouton('[data-zoom="-1"]', () => etat.carte?.zoomOut());
  bouton('[data-action="fit"]', () => cadrer());

  /* ------------------------------------------------------------------- API */
  const api = {
    el,
    state: etat,
    setClient(pos) {
      const p = pos && nb(pos.lat) != null ? { lat: Number(pos.lat), lng: Number(pos.lng) } : null;
      if (!p || etat.destruction) return;
      etat.client = { ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(), titre: 'Client' };
      etat.maj++;
      peindre();
    },
    setCourier(pos, { id = 'defaut', nom = '' } = {}) {
      const p = pos && nb(pos.lat) != null ? { lat: Number(pos.lat), lng: Number(pos.lng) } : null;
      if (!p || etat.destruction) return;
      const fiche = { ...p, accuracy: Number(pos.accuracy) || 0, at: pos.at || Date.now(), titre: nom ? `Livreur ${nom}` : 'Livreur' };
      etat.livreurs.set(id, fiche);
      etat.livreur = fiche;                  /* le dernier reçu = celui du suivi */
      etat.maj++;
      peindre();
    },
    clearCourier() {
      if (etat.destruction) return;
      etat.livreur = null;
      etat.livreurs.clear();
      etat.maj++;
      peindre();
    },
    fit() { cadrer(); },
    invalidate() { setTimeout(() => etat.carte?.invalidateSize(), 120); },
    info() {
      return {
        mode: 'osm', pret: etat.pret, erreur: etat.erreur, source: 'openstreetmap-leaflet',
        client: etat.client ? `${etat.client.lat},${etat.client.lng}` : null,
        livreur: etat.livreur ? `${etat.livreur.lat},${etat.livreur.lng}` : null,
        livreurs: etat.livreurs.size, maj: etat.maj,
      };
    },
    destroy() {
      etat.destruction = true;
      clearInterval(etat.minuteur);
      if (etat.carte) { etat.carte.remove(); etat.carte = null; }
      el.innerHTML = '';
      el.classList.remove('pcmap', 'pcosm');
    },
  };

  /* Le bandeau se rafraîchit tout seul (« relevée il y a 3 s »). */
  etat.minuteur = setInterval(() => { if (!etat.destruction) majBandeau(); }, 4000);
  window.addEventListener('pagehide', () => clearInterval(etat.minuteur), { once: true });

  return api;
}

/* ------------------------------------------------------------ utilitaires */
/** Texte lisible : distance entre le livreur et le client. */
export function routeText(courier, client) {
  if (!courier || !client) return '';
  const R = 6371000;
  const dLat = ((client.lat - courier.lat) * Math.PI) / 180;
  const dLng = ((client.lng - courier.lng) * Math.PI) / 180;
  const la1 = (courier.lat * Math.PI) / 180;
  const la2 = (client.lat * Math.PI) / 180;
  const h = Math.sin(dLat / 2) ** 2 + Math.cos(la1) * Math.cos(la2) * Math.sin(dLng / 2) ** 2;
  const m = 2 * R * Math.asin(Math.sqrt(h));
  return `${distanceLabel(m)} de vous`;
}
