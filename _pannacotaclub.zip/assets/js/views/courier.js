/* ==========================================================================
   PANNACOTTACLUB — espace livreur
   Connexion persistante (session 30 jours) · commandes assignées
   automatiquement · suivi GPS actif · encaissement · livraison
   ========================================================================== */
import {
  api, store, euro, heure, heureSec, esc, ic, toast, ui, navigate,
  live, connection, LS, K, vibrate, distanceLabel, watchPosition, getPosition,
  rememberEmail, lastEmail,
} from '../core.js?v=20261019i';
import { createMap, mapsLink } from '../map.js?v=20261019i';

let liveStop = null;
let watchStop = null;
let mapCtl = null;
let dash = null;
let sendTimer = null;
let lastSent = { lat: 0, lng: 0, at: 0 };
let geoFail = 0;

const STEP_BUTTONS = {
  received: [{ status: 'preparing', label: 'En préparation' }],
  preparing: [{ status: 'ready', label: 'Commande prête' }],
  ready: [{ status: 'en_route', label: 'Je pars en livraison' }],
  assigned: [{ status: 'en_route', label: 'Je pars en livraison' }],
  en_route: [{ status: 'arrived', label: 'Je suis arrivé' }],
  nearby: [{ status: 'arrived', label: 'Je suis arrivé' }],
  arrived: [],
};

/* ============================================================ CONNEXION ==== */
export async function renderCourier(root) {
  const token = (LS.get(K.tokens, {}).courier) || null;
  api.token = token;

  // La session vit sur le serveur (cookie httpOnly, 90 jours) et non dans ce
  // navigateur : on demande donc TOUJOURS qui l'on est, même sans jeton local.
  // C'est ce qui évite le faux « session expirée » après un nettoyage du
  // navigateur ou l'ouverture du site depuis un autre appareil.
  {
    try {
      const me = await api.get('/api/auth/me');
      if (me.user.role === 'admin') {
        // Un administrateur n'est pas livreur : on l'oriente clairement.
        root.innerHTML = `
          <div class="auth-shell"><div class="auth-card center fade-in">
            <img class="brand-logo" src="assets/img/logo.png" alt="">
            <h2>Compte administrateur</h2>
            <p class="small muted">Cette page est réservée aux livreurs. Votre compte administrateur donne accès au pilotage complet.</p>
            <a class="btn btn-block mt-2" href="admin" data-link>ALLER À L'ADMINISTRATION</a>
            <a class="btn btn-block btn-outline mt-1" href="./" data-link>Retour au site</a>
          </div></div>`;
        return undefined;
      }
      if (me.user.role === 'courier') {
        store.session = me.user;
        return renderDashboard(root);
      }
    } catch { /* session invalide → formulaire */ }
  }
  renderLogin(root);
  return undefined;
}

function renderLogin(root, message = '', kind = 'info') {
  api.token = null;
  const savedEmail = lastEmail() || 'livreur@pannacottaclub.fr';

  root.innerHTML = `
  <div class="auth-shell">
    <div class="auth-card fade-in">
      <img class="brand-logo" src="assets/img/logo.png" alt="PANNACOTTACLUB">
      <h2 class="center" style="margin-bottom:4px">Espace livreur</h2>
      <p class="center small muted">Connectez-vous pour recevoir vos commandes et partager votre position.</p>
      ${message ? `<div class="banner ${kind === 'info' ? '' : 'banner-error'} mb-2">${ic(kind === 'info' ? 'info' : 'alert')}<div>${esc(message)}</div></div>` : ''}
      <form id="loginForm" novalidate>
        <label class="field">
          <span class="label">Email</span>
          <input class="input" type="email" id="lEmail" autocomplete="username" inputmode="email" required value="${esc(savedEmail)}">
        </label>
        <label class="field">
          <span class="label">Mot de passe</span>
          <input class="input" type="password" id="lPass" autocomplete="current-password" required placeholder="••••••••">
        </label>
        <label class="switch mb-2">
          <input type="checkbox" id="lRemember" checked>
          <span class="track"></span>
          <span class="small strong">Rester connecté sur cet appareil <span class="muted">(90 jours)</span></span>
        </label>
        <div id="loginErr"></div>
        <button class="btn btn-block mt-2" type="submit" id="lSubmit">${ic('lock')} SE CONNECTER</button>
      </form>
      <p class="small muted center mt-3 mb-0">Connexion réservée à l’équipe PannacottaClub.<br>Le mot de passe n’est jamais stocké sur le téléphone.</p>
    </div>
  </div>`;

  const form = root.querySelector('#loginForm');
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const err = root.querySelector('#loginErr');
    const btn = root.querySelector('#lSubmit');
    err.innerHTML = '';
    btn.disabled = true;
    btn.innerHTML = '<span class="spin"></span> Connexion…';
    try {
      const email = root.querySelector('#lEmail').value.trim();
      const res = await api.post('/api/auth/login', {
        role: 'courier',
        identifier: email,
        password: root.querySelector('#lPass').value,
        remember: root.querySelector('#lRemember').checked,
      });
      const tokens = LS.get(K.tokens, {});
      tokens.courier = res.token;
      LS.set(K.tokens, tokens);
      rememberEmail(email);
      api.token = res.token;
      store.session = res.user;
      toast(`Bonjour ${res.user.name} 👋`, 'ok');
      renderDashboard(root);
    } catch (e2) {
      err.innerHTML = `<div class="banner banner-error mb-2">${ic('alert')}<div>${esc(e2.message)}</div></div>`;
      btn.disabled = false;
      btn.innerHTML = `${ic('lock')} SE CONNECTER`;
    }
  });
}

async function logout(root) {
  try { await api.post('/api/auth/logout'); } catch { /* ignore */ }
  const tokens = LS.get(K.tokens, {});
  delete tokens.courier;
  LS.set(K.tokens, tokens);
  api.token = null;
  store.session = null;
  liveStop?.(); watchStop?.(); mapCtl?.destroy();
  toast('Déconnecté.');
  navigate('livreur');
}

/* =========================================================== TABLEAU DE BORD = */
async function renderDashboard(root) {
  root.innerHTML = `
    <section class="wrap" style="padding-top:20px">
      <div id="courierHead"></div>
      <div id="courierStats" class="grid-3 mt-2"></div>
      <div id="courierGeo" class="mt-2"></div>
      <div class="mt-3" id="courierOrders"></div>
      <div class="mt-3" id="courierQueue"></div>
      <div class="map mt-3" id="courierMap" style="height:280px"></div>
      <div class="mt-3" id="courierRecent"></div>
    </section>`;

  await loadDashboard(root);

  liveStop?.();
  liveStop = live(`/api/events/courier?token=${encodeURIComponent(api.token || '')}`, {
    'order:new': () => { toast('Nouvelle commande !', 'ok'); vibrate([20, 60, 20]); loadDashboard(root); },
    'order:assigned': () => { toast('Une commande vous a été assignée.', 'ok'); vibrate([20, 60, 20]); loadDashboard(root); },
    'order:update': () => loadDashboard(root, { silent: true }),
    'settings:update': () => loadDashboard(root, { silent: true }),
  });

  startPositionSharing(root);
}

async function loadDashboard(root, { silent = false } = {}) {
  try {
    dash = await api.get('/api/courier/dashboard');
  } catch (err) {
    if (err.status === 401) {
      const tokens = LS.get(K.tokens, {});
      delete tokens.courier;
      LS.set(K.tokens, tokens);
      api.token = null;
      renderLogin(root, 'Reconnectez-vous pour reprendre : vos livraisons en cours restent enregistrées et vous retrouverez tout à l’identique.');
      return;
    }
    if (!silent) toast(err.message, 'err');
    return;
  }

  paintHead(root);
  paintStats(root);
  paintOrders(root);
  paintQueue(root);
  paintRecent(root);
  paintMap(root);
}

function paintHead(root) {
  const c = dash.courier;
  const el = root.querySelector('#courierHead');
  if (!el) return;
  el.innerHTML = `
    <div class="card">
      <div class="row-between">
        <div>
          <div class="eyebrow mb-1">Espace livreur</div>
          <h2 class="mb-0">Bonjour ${esc(c.name)}</h2>
          <div class="small muted mt-1">${dash.stats.delivered} livraisons effectuées</div>
        </div>
        <button class="btn btn-sm btn-ghost" id="logoutBtn">${ic('logout')} Quitter</button>
      </div>
      <div class="divider"></div>
      <div class="row-between">
        <label class="switch">
          <input type="checkbox" id="onlineToggle" ${c.online ? 'checked' : ''}>
          <span class="track"></span>
          <span class="strong">${c.online ? 'En service' : 'Hors service'}</span>
        </label>
        <span class="tag ${dash.settings.autoAssign ? 'tag-solid' : 'tag-line'}">
          ${dash.settings.autoAssign ? 'Assignation automatique' : 'Prise de commande manuelle'}
        </span>
      </div>
    </div>`;
  el.querySelector('#logoutBtn').addEventListener('click', () => logout(root));
  el.querySelector('#onlineToggle').addEventListener('change', async (e) => {
    const online = e.currentTarget.checked;
    try {
      await api.post('/api/courier/online', { online });
      dash.courier.online = online;
      toast(online ? 'Vous êtes en service.' : 'Vous êtes hors service.', 'ok');
      paintHead(root);
    } catch (err) { toast(err.message, 'err'); }
  });
}

function paintStats(root) {
  const el = root.querySelector('#courierStats');
  if (!el) return;
  el.innerHTML = `
    <div class="stat"><div class="k">En cours</div><div class="v">${dash.orders.length}</div></div>
    <div class="stat"><div class="k">Encaissé aujourd'hui</div><div class="v mono">${euro(dash.stats.cashToday)}</div></div>
    <div class="stat"><div class="k">À encaisser</div><div class="v mono">${euro(dash.orders.reduce((s, o) => s + (o.paymentStatus === 'paid' ? 0 : o.total), 0))}</div></div>`;
}

function paintOrders(root) {
  const el = root.querySelector('#courierOrders');
  if (!el) return;
  if (!dash.orders.length) {
    el.innerHTML = `<div class="card"><div class="card-head"><h3>Mes livraisons en cours</h3></div>
      <p class="small muted mb-0">Aucune commande pour le moment. Restez en service : la prochaine commande arrive automatiquement, même l’écran éteint, dès que vous rouvrez la page.</p></div>`;
    return;
  }
  el.innerHTML = dash.orders.map(orderCard).join('');
  el.querySelectorAll('[data-action]').forEach((btn) => {
    btn.addEventListener('click', () => handleAction(root, btn.dataset.action, btn.dataset.id, btn));
  });
}

function orderCard(o) {
  const buttons = STEP_BUTTONS[o.status] || [];
  const fresh = Date.now() - (o.createdAt || 0);
  const newBadge = fresh < 1000 * 60 * 3 ? '<span class="tag tag-solid">Nouveau</span>' : '';
  const unpaid = o.paymentStatus !== 'paid';
  const startedAt = o.history?.find((h) => h.status === 'en_route')?.at;
  const elapsed = startedAt ? Math.round((Date.now() - startedAt) / 60000) : null;

  return `
  <article class="admin-order fade-in" data-card="${o.id}">
    <header>
      <div>
        <div class="ono">${esc(o.id)} ${newBadge}</div>
        <div class="meta">${esc(o.customer.firstName)} · ${heure(o.createdAt)}${o.distance != null ? ` · ${distanceLabel(o.distance)}` : ''}${elapsed != null ? ` · en route depuis ${elapsed} min` : ''}</div>
      </div>
      <span class="pill ${o.status === 'arrived' ? 'ok' : o.status === 'delivered' ? 'grey' : 'warn'}">${esc(o.statusLabel)}</span>
    </header>

    <div class="banner ${unpaid ? '' : ''}" style="background:${unpaid ? 'var(--blue)' : 'var(--blue-050)'};color:${unpaid ? '#fff' : 'var(--blue)'};border-color:transparent;justify-content:space-between">
      <span style="display:flex;gap:10px;align-items:center">${ic('euro')} <strong>À ENCAISSER : ${euro(o.total)}</strong></span>
      <span class="small">${unpaid ? 'Espèces / sans contact' : 'Déjà payé'}</span>
    </div>

    <ul>
      ${o.items.map((i) => `<li>${i.qty} × ${esc(i.name)}</li>`).join('')}
    </ul>

    <div class="row-between small">
      <span><strong>Client :</strong> ${esc(o.customer.firstName)}${o.customer.phone ? ` · <a href="tel:${esc(o.customer.phone.replace(/\s/g, ''))}">${esc(o.customer.phone)}</a>` : ''}</span>
      <span class="mono">${o.location
        ? `${o.location.lat.toFixed(5)}, ${o.location.lng.toFixed(5)}${o.location.accuracy > 80 ? ' (±' + Math.round(o.location.accuracy) + ' m)' : ''}`
        : '<span style="color:#8A0018;font-weight:700">POSITION NON TRANSMISE</span>'}</span>
    </div>
    ${o.customer.note ? `<p class="small mt-1 mb-0"><strong>Repère :</strong> ${esc(o.customer.note)}</p>` : ''}

    ${!o.location ? `<div class="banner banner-error mt-2" style="justify-content:flex-start">${ic('alert')}<div><strong>Ce client n'a pas transmis sa position.</strong><br><span class="small">Appelez-le pour convenir du point de rendez-vous : les indications écrites sont en dessous.</span></div></div>` : ''}
    <div class="acts">
      ${buttons.map((b) => `<button class="btn btn-sm" data-action="status" data-id="${o.id}" data-status="${b.status}">${esc(b.label)}</button>`).join('')}
      ${!unpaid && o.status !== 'delivered' ? `<button class="btn btn-sm btn-outline" data-action="deliver" data-id="${o.id}">${ic('check')} LIVRÉE</button>` : ''}
      ${unpaid ? `<button class="btn btn-sm btn-outline" data-action="paid" data-id="${o.id}">${ic('euro')} PAIEMENT REÇU</button>` : ''}
      ${unpaid ? '' : ''}
      <a class="btn btn-sm btn-outline" href="${o.location ? mapsLink(o.location) : '#'}" target="_blank" rel="noopener">${ic('route')} Itinéraire</a>
      ${o.customer.phone ? `<a class="btn btn-sm btn-ghost" href="tel:${esc(o.customer.phone.replace(/\s/g, ''))}">${ic('phone')} Appeler</a>` : ''}
    </div>
    ${o.status === 'delivered' && o.paymentStatus !== 'paid' ? `<p class="small mt-2 mb-0" style="color:#8A0018;font-weight:600">Livrée mais non encaissée — pensez à régulariser dans l’admin.</p>` : ''}
  </article>`;
}

function paintQueue(root) {
  const el = root.querySelector('#courierQueue');
  if (!el) return;
  if (!dash.queue.length) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="card">
      <div class="card-head"><h3>Commandes disponibles</h3><span class="small muted">Non assignées</span></div>
      ${dash.queue.map((o) => `
        <div class="line-item">
          <div class="grow">
            <div class="nm">${esc(o.id)} · ${esc(o.customer.firstName)}</div>
            <div class="pr">${o.items.length} article(s) · ${euro(o.total)}${o.distance != null ? ` · ${distanceLabel(o.distance)}` : ''}</div>
          </div>
          <button class="btn btn-xs" data-accept="${o.id}">PRENDRE LA COMMANDE</button>
        </div>`).join('')}
    </div>`;
  el.querySelectorAll('[data-accept]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try {
      await api.post(`/api/courier/orders/${encodeURIComponent(b.dataset.accept)}/accept`);
      toast('Commande prise en charge.', 'ok');
      vibrate(20);
      loadDashboard(root);
    } catch (err) { toast(err.message, 'err'); b.disabled = false; }
  }));
}

function paintRecent(root) {
  const el = root.querySelector('#courierRecent');
  if (!el) return;
  if (!dash.recent.length) { el.innerHTML = ''; return; }
  el.innerHTML = `
    <div class="card">
      <div class="card-head"><h3>Dernières livraisons</h3><span class="tag">${dash.stats.delivered} au total</span></div>
      ${dash.recent.map((o) => `
        <div class="line-item">
          <div class="grow">
            <div class="nm">${esc(o.id)} · ${esc(o.customer.firstName)}</div>
            <div class="pr">${heure(o.createdAt)} · ${euro(o.total)} · ${o.paymentStatus === 'paid' ? 'encaissé' : 'non encaissé'}</div>
          </div>
          ${o.paymentStatus === 'paid' ? '<span class="pill ok">Payé</span>' : `<button class="btn btn-xs btn-outline" data-paid="${o.id}">PAIEMENT REÇU</button>`}
        </div>`).join('')}
    </div>`;
  el.querySelectorAll('[data-paid]').forEach((b) => b.addEventListener('click', async () => {
    b.disabled = true;
    try {
      await api.post(`/api/courier/orders/${encodeURIComponent(b.dataset.paid)}/paid`, { paid: true });
      toast('Paiement enregistré.', 'ok');
      loadDashboard(root);
    } catch (err) { toast(err.message, 'err'); b.disabled = false; }
  }));
}

function paintMap(root) {
  const el = root.querySelector('#courierMap');
  if (!el) return;
  if (mapCtl && mapCtl.el === el) { updateCourierMarkers(); return; }  // réutilise la carte existante
  mapCtl?.destroy();
  mapCtl = createMap(el, {
    center: dash.courier.lastPos || dash.settings.zone || { lat: 49.2915, lng: -0.1212 },
    zoom: 16,
    zone: dash.settings.zone,
  });
  if (dash.courier.lastPos) {
    mapCtl.setCourier(dash.courier.lastPos, { id: dash.courier.id, nom: dash.courier.name, animate: false });
  }
  updateCourierMarkers(true);
}

function updateCourierMarkers(first = false) {
  if (!mapCtl) return;
  const target = dash.orders.find((o) => o.location);
  if (target) mapCtl.setClient(target.location, { focus: first && !dash.courier.lastPos });
  if (dash.courier.lastPos) {
    mapCtl.setCourier(dash.courier.lastPos, { id: dash.courier.id, nom: dash.courier.name, animate: false });
  }
  if (first) mapCtl.fit();
}

async function handleAction(root, action, id, btn) {
  btn.disabled = true;
  const original = btn.innerHTML;
  btn.innerHTML = '<span class="spin blue" style="width:16px;height:16px"></span>';
  try {
    if (action === 'status') {
      await api.post(`/api/courier/orders/${encodeURIComponent(id)}/status`, { status: btn.dataset.status });
      vibrate(16);
      toast('Statut mis à jour.', 'ok');
    } else if (action === 'paid') {
      await api.post(`/api/courier/orders/${encodeURIComponent(id)}/paid`, { paid: true });
      toast('Paiement encaissé.', 'ok');
    } else if (action === 'deliver') {
      await api.post(`/api/courier/orders/${encodeURIComponent(id)}/status`, { status: 'delivered' });
      toast('Commande livrée. Merci !', 'ok');
      vibrate([16, 40, 16]);
    }
    await loadDashboard(root, { silent: true });
  } catch (err) {
    toast(err.message, 'err');
    btn.disabled = false;
    btn.innerHTML = original;
  }
}

/* ====================================================== PARTAGE DE POSITION */
function startPositionSharing(root) {
  const paint = (state, detail = '') => {
    const el = root.querySelector('#courierGeo');
    if (!el) return;
    const map = {
      off: `<div class="banner banner-offline">${ic('wifioff')}<div><strong>Position non partagée.</strong> Autorisez la localisation pour que le client voie votre approche.<br><span class="small">${esc(detail)}</span></div></div>`,
      waiting: `<div class="banner">${ic('clock')}<div><strong>Recherche de votre position…</strong><br><span class="small">Restez quelques secondes à découvert, près du bord de plage.</span></div></div>`,
      on: `<div class="banner">${ic('pin')}<div><strong>Position partagée en direct.</strong> ${detail}</div></div>`,
    };
    el.innerHTML = map[state] || '';
  };

  paint('waiting');

  const onPos = (pos) => {
    geoFail = 0;
    const moved = Math.abs(pos.lat - lastSent.lat) + Math.abs(pos.lng - lastSent.lng);
    const due = Date.now() - lastSent.at > 8000;
    const send = async () => {
      lastSent = { lat: pos.lat, lng: pos.lng, at: Date.now() };
      try {
        await api.post('/api/courier/location', pos);
        paint('on', `${pos.lat.toFixed(5)}, ${pos.lng.toFixed(5)} · ± ${Math.round(pos.accuracy || 0)} m · ${heureSec(pos.at)}`);
      } catch (err) {
        if (err.status === 401) {
          const tokens = LS.get(K.tokens, {});
          delete tokens.courier;
          LS.set(K.tokens, tokens);
          api.token = null;
          watchStop?.(); liveStop?.();
          renderLogin(root, 'Reconnectez-vous pour reprendre le partage de votre position. Vos livraisons sont conservées.');
        } else {
          paint('off', err.message);
        }
      }
    };
    if (moved > 0.00008 || due || lastSent.at === 0) send();
  };

  const onErr = (err) => {
    geoFail += 1;
    const msg = err.code === 1
      ? 'Localisation refusée. Autorisez-la dans les réglages du navigateur.'
      : 'Position momentanément indisponible.';
    paint('off', msg);
  };

  watchStop?.();
  if ('geolocation' in navigator) {
    // watchPosition() de core.js renvoie { lat, lng, accuracy, at } : format attendu par l'API.
    watchStop = watchPosition(onPos, onErr);
    // filet de sécurité : si aucun envoi depuis 30 s (téléphone en veille, onglet figé), on relance.
    clearInterval(sendTimer);
    sendTimer = setInterval(() => {
      if (Date.now() - lastSent.at > 30000) {
        getPosition({ timeout: 20000 }).then(onPos).catch(onErr);
      }
    }, 15000);
  } else {
    paint('off', 'Ce navigateur ne fournit pas la position.');
  }
}

export function stopCourierLive() {
  liveStop?.(); liveStop = null;
  watchStop?.(); watchStop = null;
  clearInterval(sendTimer);
  mapCtl?.destroy();
}
