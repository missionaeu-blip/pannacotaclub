/* ==========================================================================
   PANNACOTTACLUB — espace administrateur
   Produits (prix, ajout, retrait) · Commandes · Livreurs · Carte · QR codes
   ========================================================================== */
import {
  api, store, euro, prodImg, heure, heureSec, esc, ic, toast, ui, navigate,
  live, LS, K, distanceLabel, rememberEmail, lastEmail, BASE,
} from '../core.js?v=20261019i';
import { ACCES_DIGUE } from '../map.js?v=20261019i';
import { createMap, mapsLink } from '../map.js?v=20261019i';

let liveStop = null;
let mapCtl = null;
let state = null;
let tab = 'orders';

const TABS = [
  { id: 'orders', label: 'Commandes' },
  { id: 'map', label: 'Carte' },
  { id: 'products', label: 'Produits & prix' },
  { id: 'stock', label: 'Inventaire' },
  { id: 'couriers', label: 'Livreurs' },
  { id: 'qr', label: 'Panneaux QR' },
  { id: 'settings', label: 'Réglages' },
];

/* ============================================================== CONNEXION == */
export async function renderAdmin(root) {
  api.token = (LS.get(K.tokens, {}).admin) || null;

  // Le cookie de session du serveur fait foi : on vérifie toujours.
  {
    try {
      const me = await api.get('/api/auth/me');
      if (me.user.role === 'admin') { store.session = me.user; return renderBoard(root); }
    } catch { /* ignore */ }
  }
  renderLogin(root);
  return undefined;
}

function renderLogin(root, message = '') {
  api.token = null;
  const savedEmail = lastEmail() || 'admin@pannacottaclub.fr';
  root.innerHTML = `
  <div class="auth-shell">
    <div class="auth-card fade-in">
      <img class="brand-logo" src="assets/img/logo.png" alt="PANNACOTTACLUB">
      <h2 class="center" style="margin-bottom:4px">Administration</h2>
      <p class="center small muted">Produits, commandes, livreurs et zone de livraison.</p>
      ${message ? `<div class="banner banner-error mb-2">${ic('alert')}<div>${esc(message)}</div></div>` : ''}
      <form id="adminLogin" novalidate>
        <label class="field">
          <span class="label">Email</span>
          <input class="input" type="email" id="aEmail" autocomplete="username" value="${esc(savedEmail)}">
        </label>
        <label class="field">
          <span class="label">Mot de passe</span>
          <input class="input" type="password" id="aPass" autocomplete="current-password" placeholder="••••••••">
        </label>
        <div id="adminErr"></div>
        <button class="btn btn-block mt-2" type="submit" id="aSubmit">${ic('lock')} SE CONNECTER</button>
        <label class="switch mt-2"><input type="checkbox" id="aRemember" checked><span class="track"></span><span class="small strong">Rester connecté</span></label>
      </form>
    </div>
  </div>`;

  root.querySelector('#adminLogin').addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = root.querySelector('#aSubmit');
    const err = root.querySelector('#adminErr');
    err.innerHTML = '';
    btn.disabled = true;
    btn.innerHTML = '<span class="spin"></span> Connexion…';
    try {
      const adminEmail = root.querySelector('#aEmail').value.trim();
      const res = await api.post('/api/auth/login', {
        role: 'admin',
        identifier: adminEmail,
        password: root.querySelector('#aPass').value,
        remember: root.querySelector('#aRemember').checked,
      });
      const tokens = LS.get(K.tokens, {});
      tokens.admin = res.token;
      LS.set(K.tokens, tokens);
      rememberEmail(adminEmail);
      api.token = res.token;
      store.session = res.user;
      renderBoard(root);
    } catch (e2) {
      err.innerHTML = `<div class="banner banner-error mb-2">${ic('alert')}<div>${esc(e2.message)}</div></div>`;
      btn.disabled = false;
      btn.innerHTML = `${ic('lock')} SE CONNECTER`;
    }
  });
}

/* ========================================================== TABLEAU DE BORD = */
async function renderBoard(root) {
  root.innerHTML = `
    <section class="wrap wrap-wide" style="padding-top:18px">
      <div class="row-between">
        <div>
          <div class="eyebrow mb-1">Administration</div>
          <h2 class="mb-0">PannacottaClub · Cabourg</h2>
        </div>
        <button class="btn btn-sm btn-ghost" id="adminLogout">${ic('logout')} Quitter</button>
      </div>
      <div class="grid-3 mt-3" id="adminStats"></div>
      <div class="tabs mt-3" id="adminTabs">
        ${TABS.map((t) => `<button class="tab ${t.id === tab ? 'active' : ''}" data-tab="${t.id}">${esc(t.label)}</button>`).join('')}
      </div>
      <div id="adminPanel" class="mt-3" style="padding-bottom:60px"></div>
    </section>`;

  root.querySelector('#adminLogout').addEventListener('click', logout);
  root.querySelector('#adminTabs').addEventListener('click', (e) => {
    const b = e.target.closest('[data-tab]');
    if (!b) return;
    tab = b.dataset.tab;
    root.querySelectorAll('.tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === tab));
    paintPanel(root);
  });

  await refresh(root);

  liveStop?.();
  liveStop = live(`/api/events/admin?token=${encodeURIComponent(api.token || '')}`, {
    'order:new': () => { toast('Nouvelle commande reçue.', 'ok'); refresh(root, { silent: true }); },
    'order:update': () => refresh(root, { silent: true }),
    'courier:position': (p) => onCourierPosition(root, p),
    'courier:update': () => refresh(root, { silent: true }),
    'couriers:update': () => refresh(root, { silent: true }),
    'menu:update': () => refresh(root, { silent: true }),
    'settings:update': () => refresh(root, { silent: true }),
  });
}

async function logout() {
  try { await api.post('/api/auth/logout'); } catch { /* ignore */ }
  const tokens = LS.get(K.tokens, {});
  delete tokens.admin;
  LS.set(K.tokens, tokens);
  liveStop?.();
  mapCtl?.destroy();
  navigate('admin');
}

async function refresh(root, { silent = false } = {}) {
  try {
    state = await api.get('/api/admin/state');
  } catch (err) {
    if (err.status === 401) { renderLogin(root, 'Reconnectez-vous : vos commandes et vos réglages sont intacts.'); return; }
    if (!silent) toast(err.message, 'err');
    return;
  }
  await decompterStocks(root);
  paintStats(root);
  paintPanel(root);
}

function paintStats(root) {
  const s = state.stats;
  const el = root.querySelector('#adminStats');
  if (!el) return;
  el.innerHTML = `
    <div class="stat"><div class="k">Commandes aujourd'hui</div><div class="v">${s.ordersToday}</div><div class="small muted">${s.active} en cours · ${s.unassigned} sans livreur</div></div>
    <div class="stat"><div class="k">Chiffre du jour</div><div class="v mono">${euro(s.revenueToday)}</div><div class="small muted">${s.unpaid} paiement(s) à régulariser</div></div>
    <div class="stat"><div class="k">Livreurs</div><div class="v">${s.onlineCouriers}<span class="small muted">/${state.couriers.length}</span></div><div class="small muted">en service maintenant</div></div>`;
}

function paintPanel(root) {
  const el = root.querySelector('#adminPanel');
  if (!el || !state) return;
  if (tab === 'orders') paintOrders(root, el);
  else if (tab === 'map') paintMap(root, el);
  else if (tab === 'products') paintProducts(root, el);
  else if (tab === 'stock') paintStock(root, el);
  else if (tab === 'couriers') paintCouriers(root, el);
  else if (tab === 'qr') paintQr(root, el);
  else paintSettings(root, el);
}

/* ============================================================ INVENTAIRE == */
/* Inventaire très simple : un nombre par article, des boutons + et −.
   Chaque commande décompte automatiquement le stock (décompterStocks) et,
   à zéro, l'article est marqué « Épuisé » et ne peut plus être ajouté au
   panier par les clients. Toucher le nombre pour le saisir directement. */
const CLE_STOCK_COMPTE = 'pc-stock-compte';

async function majStock(root, p, valeur) {
  const n = Math.max(0, Math.min(9999, Math.round(valeur)));
  p.stock = n;   /* optimiste : l'affichage réagit immédiatement */
  const el = root.querySelector('#adminPanel');
  if (el && tab === 'stock') paintStock(root, el);
  try {
    await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { stock: n });
  } catch (err) { toast(err.message, 'err'); }
}

function paintStock(root, el) {
  const ps = state.products || [];
  el.innerHTML = `
    <div class="row-between mb-2">
      <h3 class="mb-0">Inventaire</h3>
      <span class="small muted">Chaque vente décompte automatiquement.</span>
    </div>
    <p class="small muted">Touchez un nombre pour le saisir directement. À zéro, l'article est marqué <strong>Épuisé</strong> et ne peut plus être commandé par les clients.</p>
    <div class="card">
      ${ps.map((p) => {
        const n = Number(p.stock);
        const suivi = Number.isFinite(n);
        const epuise = suivi && n <= 0;
        return `
        <div class="stock-line row-between" style="padding:12px 0;border-bottom:1px solid #EEF0FF">
          <div>
            <strong>${esc(p.name)}</strong>
            ${epuise ? ' <span class="pc-epuise">Épuisé</span>' : ''}
            ${p.available === false ? ' <span class="small muted">(retiré de la vente)</span>' : ''}
          </div>
          <div style="display:flex;align-items:center;gap:10px">
            <button class="btn btn-sm btn-outline" data-stock-moins="${p.id}" aria-label="Retirer un ${esc(p.name)}">−</button>
            <span class="mono" data-stock-n="${p.id}" role="button" tabindex="0" style="min-width:38px;text-align:center;font-weight:800;font-size:1.05rem;cursor:pointer">${suivi ? n : '—'}</span>
            <button class="btn btn-sm btn-outline" data-stock-plus="${p.id}" aria-label="Ajouter un ${esc(p.name)}">+</button>
          </div>
        </div>`; }).join('')}
    </div>`;
  const trouve = (id) => state.products.find((x) => x.id === id);
  el.querySelectorAll('[data-stock-moins]').forEach((b) => b.addEventListener('click', () => {
    const p = trouve(b.dataset.stockMoins);
    const n = Number(p.stock);
    majStock(root, p, Number.isFinite(n) ? n - 1 : 0);
  }));
  el.querySelectorAll('[data-stock-plus]').forEach((b) => b.addEventListener('click', () => {
    const p = trouve(b.dataset.stockPlus);
    const n = Number(p.stock);
    majStock(root, p, Number.isFinite(n) ? n + 1 : 1);
  }));
  el.querySelectorAll('[data-stock-n]').forEach((sp) => {
    const saisir = () => {
      const p = trouve(sp.dataset.stockN);
      const rep = prompt(`Stock « ${p.name} » (nombre entier) :`, Number.isFinite(Number(p.stock)) ? String(p.stock) : '0');
      if (rep === null) return;
      const v = parseInt(rep, 10);
      if (!Number.isFinite(v)) { toast('Nombre invalide.'); return; }
      majStock(root, p, v);
    };
    sp.addEventListener('click', saisir);
    sp.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') saisir(); });
  });
}

/* Décompte automatique : dès qu'une nouvelle commande apparaît dans l'état
   admin, son contenu est retiré du stock, une seule fois par commande.
   La toute première ouverture n'impose PAS l'historique existant. */
async function decompterStocks(root) {
  if (!state?.orders || !state?.products) return;
  const avant = LS.get(CLE_STOCK_COMPTE, null);
  if (avant === null) {   /* première ouverture : on fige l'historique tel quel */
    LS.set(CLE_STOCK_COMPTE, state.orders.map((o) => o.id).slice(-300));
    return;
  }
  const faits = new Set(Array.isArray(avant) ? avant : []);
  const aTraiter = state.orders.filter((o) => !faits.has(o.id) && o.status !== 'cancelled');
  if (!aTraiter.length) return;
  for (const o of aTraiter) {
    faits.add(o.id);
    for (const i of (o.items || [])) {
      const pid = i.productId || i.id;
      const p = state.products.find((x) => x.id === pid) || state.products.find((x) => x.name === i.name);
      const n = Number(p?.stock);
      if (p && Number.isFinite(n) && n > 0) {
        const reste = Math.max(0, n - (i.qty || 1));
        try {
          await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { stock: reste });
          p.stock = reste;
        } catch { /* retentera à la prochaine commande */ }
      }
    }
  }
  LS.set(CLE_STOCK_COMPTE, [...faits].slice(-300));
  toast(`${aTraiter.length} commande(s) — inventaire décompté.`, 'ok');
}

/* =============================================================== COMMANDES = */
function paintOrders(root, el) {
  const active = state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status));
  const past = state.orders.filter((o) => ['delivered', 'cancelled'].includes(o.status)).slice(0, 30);

  const mode = state.settings?.acceptingOrders === false ? 'ferme' : 'ouvert';
  const LIBELLES = { ouvert: 'OUVERT — les clients peuvent commander', ferme: 'FERMÉ — plus aucune commande possible' };
  el.innerHTML = `
    <div class="card card-flat" style="padding:12px 14px;margin-bottom:14px">
      <div class="row-between">
        <div>
          <strong>Prise de commandes : ${LIBELLES[mode]}</strong>
          <div class="small muted">Tu décides, avec ou sans les horaires.</div>
        </div>
        <div class="btn-row">
          <button class="btn btn-xs ${mode === 'ouvert' ? '' : 'btn-outline'}" data-mode="ouvert">OUVRIR</button>
          <button class="btn btn-xs ${mode === 'ferme' ? '' : 'btn-outline'}" data-mode="ferme">FERMER</button>
        </div>
      </div>
    </div>
    <div class="row-between mb-2">
      <h3 class="mb-0">Commandes en cours (${active.length})</h3>
      <button class="btn btn-xs btn-outline" id="demoOrder">${ic('plus')} Commande test</button>
    </div>
    ${active.length ? active.map((o) => adminOrderCard(o)).join('') : '<div class="card"><p class="small muted mb-0">Aucune commande en cours.</p></div>'}
    <h3 class="mt-3">Historique (${past.length})</h3>
    ${past.length ? past.map((o) => adminOrderCard(o, true)).join('') : '<div class="card"><p class="small muted mb-0">Aucune commande terminée.</p></div>'}`;

    el.querySelectorAll('[data-mode]').forEach((b) => b.addEventListener('click', async () => {
    const m = b.dataset.mode;
    /* acceptingOrders : réglage classique que le serveur enregistre sans
       problème — les deux boutons sont donc fiables à 100 %. */
    const payload = m === 'ouvert' ? { acceptingOrders: true } : { acceptingOrders: false };
    b.disabled = true;
    try {
      await api.put('/api/admin/settings', payload);
      toast(m === 'ouvert' ? 'Commandes ouvertes — les clients peuvent commander.' : 'Commandes fermées — plus aucune commande possible.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
  el.querySelector('#demoOrder').addEventListener('click', async (e) => {
    e.currentTarget.disabled = true;
    try {
      const res = await api.post('/api/admin/demo/order');
      toast(`Commande test ${res.order.id} créée.`, 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  });

  el.querySelectorAll('[data-oact]').forEach((btn) => {
    const evt = btn.tagName === 'SELECT' ? 'change' : 'click';
    btn.addEventListener(evt, async () => {
      const { oact, id } = btn.dataset;
      btn.disabled = true;
      try {
        if (oact === 'courier') {
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { courierId: btn.value || null });
          toast(btn.value ? 'Livreur assigné.' : 'Commande remise sans livreur.', 'ok');
        } else if (oact === 'paid') {
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { paymentStatus: 'paid' });
          toast('Paiement marqué encaissé.', 'ok');
        } else if (oact === 'cancel') {
          if (!confirm(`Annuler la commande ${id} ?`)) { btn.disabled = false; return; }
          await api.put(`/api/admin/orders/${encodeURIComponent(id)}`, { status: 'cancelled' });
          toast('Commande annulée.');
        }
        await refresh(root, { silent: true });
      } catch (err) { toast(err.message, 'err'); btn.disabled = false; }
    });
  });
}

function adminOrderCard(o, compact = false) {
  return `
  <article class="admin-order mb-2">
    <header>
      <div>
        <div class="ono">${esc(o.id)}</div>
        <div class="meta">${heure(o.createdAt)} · ${esc(o.customer.firstName)} · ${esc(o.customer.phone)}</div>
      </div>
      <div class="center">
        <span class="pill ${o.status === 'delivered' ? 'grey' : o.status === 'cancelled' ? 'warn' : 'ok'}">${esc(o.statusLabel)}</span>
        <div class="small muted mt-1">${o.paymentStatus === 'paid' ? 'Payé' : 'À encaisser'}</div>
      </div>
    </header>
    <div class="small">
      <strong>${esc(o.courierName || 'Aucun livreur')}</strong>
      ${o.eta ? ` · ${o.eta.minutes} min · ${distanceLabel(o.eta.distance)}` : ''}
      ${o.outOfZone ? ' · <span style="color:#8A0018;font-weight:700">hors zone</span>' : ''}
    </div>
    <ul>${o.items.map((i) => `<li>${i.qty} × ${esc(i.name)} — ${euro(i.price * i.qty)}</li>`).join('')}</ul>
    <div class="row-between">
      <span class="small muted">${o.customer.note ? `Repère : ${esc(o.customer.note)}` : ''}</span>
      <strong class="mono">${euro(o.total)}</strong>
    </div>
    ${compact ? `
      <div class="acts">
        ${o.paymentStatus !== 'paid' && o.status === 'delivered' ? `<button class="btn btn-xs btn-outline" data-oact="paid" data-id="${o.id}">Marquer payé</button>` : ''}
        ${o.location ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(o.location)}">Position</a>` : ''}
      </div>` : `
      <div class="acts">
        <select class="select" style="min-height:38px;padding:6px 10px;width:auto" data-oact="courier" data-id="${o.id}">
          <option value="">Assigner un livreur…</option>
          ${state.couriers.filter((c) => c.active).map((c) => `<option value="${c.id}" ${o.courierId === c.id ? 'selected' : ''}>${esc(c.name)}${c.online ? ' (en service)' : ''}</option>`).join('')}
        </select>
        <button class="btn btn-xs btn-outline" data-oact="paid" data-id="${o.id}">${ic('euro')} Payé</button>
        ${o.location ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(o.location)}">${ic('pin')} Voir position</a>` : ''}
        <button class="btn btn-xs btn-danger" data-oact="cancel" data-id="${o.id}">Annuler</button>
      </div>`}
  </article>`;
}

/* ==================================================================== CARTE = */
function paintMap(root, el) {
  el.innerHTML = `
    <div class="row-between mb-2">
      <h3 class="mb-0">Carte générale</h3>
      <span class="small muted" id="mapLiveCount">${state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)).length} commande(s) active(s) · ${state.couriers.filter((c) => c.online).length} livreur(s) en service</span>
    </div>
    <div class="map tall" id="adminMap" style="height:520px"></div>
    <div class="grid-2 mt-2">
      <div class="card">
        <div class="card-head"><h3>Commandes actives</h3></div>
        <div id="adminMapList"></div>
      </div>
      <div class="card">
        <div class="card-head"><h3>Livreurs</h3></div>
        <div id="adminCourierList"></div>
      </div>
    </div>`;

  const mapEl = el.querySelector('#adminMap');
  const reuse = mapCtl && mapCtl.el === mapEl;
  if (!reuse) {
    mapCtl?.destroy();
    mapCtl = createMap(mapEl, { center: state.settings.zone, zoom: 15, zone: state.settings.zone });
  }

  const active = state.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status) && o.location);
  const doneIds = new Set();
  for (const o of active) {
    if (doneIds.has(o.id)) continue;
    doneIds.add(o.id);
    mapCtl.setClient(o.location);
  }
  for (const c of state.couriers) {
    if (c.lastPos) mapCtl.setCourier({ ...c.lastPos, id: c.id, nom: c.name }, { id: c.id, nom: c.name, animate: false });
  }
  if (!reuse) { mapCtl.fit(); mapCtl.invalidate(); }

  el.querySelector('#adminMapList').innerHTML = active.length
    ? active.map((o) => `
      <div class="line-item">
        <div class="grow">
          <div class="nm">${esc(o.id)} · ${esc(o.customer.firstName)}</div>
          <div class="pr">${esc(o.statusLabel)}${o.courierName ? ` · ${esc(o.courierName)}` : ' · sans livreur'} · ${euro(o.total)}</div>
        </div>
        ${o.location ? `<a class="btn btn-xs btn-ghost" href="${mapsLink(o.location)}" target="_blank" rel="noopener">Ouvrir</a>` : ''}
      </div>`).join('')
    : '<p class="small muted mb-0">Aucune commande active.</p>';

  el.querySelector('#adminCourierList').innerHTML = state.couriers.length
    ? state.couriers.map((c) => `
      <div class="line-item">
        <div class="grow">
          <div class="nm">${esc(c.name)} ${c.online ? '<span class="pill ok">en service</span>' : '<span class="pill grey">hors service</span>'}</div>
          <div class="pr">${c.activeOrders} en cours · ${c.delivered} livrées${c.lastPos ? ` · position ${heureSec(c.lastPos.at)}` : ' · position inconnue'}</div>
        </div>
        ${c.lastPos ? `<a class="btn btn-xs btn-ghost" href="${mapsLink(c.lastPos)}" target="_blank" rel="noopener">${ic('pin')}</a>` : ''}
      </div>`).join('')
    : '<p class="small muted mb-0">Aucun livreur enregistré.</p>';
}

function onCourierPosition(root, p) {
  if (tab === 'map' && mapCtl) mapCtl.setCourier(p, { id: p.courierId || p.id || 'defaut', nom: p.courierName || p.name || '' });
  const el = root.querySelector('#mapLiveCount');
  if (el) el.textContent = `${state?.orders.filter((o) => !['delivered', 'cancelled'].includes(o.status)).length || 0} commande(s) active(s) · position livreur ${heureSec(p.at)}`;
}

/* ================================================================= PRODUITS = */
function paintProducts(root, el) {
  const cats = state.categories;
  const byCat = (id) => state.products.filter((p) => p.catId === id);

  el.innerHTML = `
    <div class="row-between mb-2">
      <div>
        <h3 class="mb-0">Produits, prix & disponibilité</h3>
        <p class="small muted mb-0">Modifiez un prix, retirez un article de la vente ou ajoutez-en un nouveau. Les clients voient la mise à jour immédiatement.</p>
      </div>
      <button class="btn btn-sm" id="newProduct">${ic('plus')} Ajouter un article</button>
    </div>

    ${cats.map((c) => `
      <h4 class="mt-3">${esc(c.name)} <span class="small muted">(${byCat(c.id).length})</span></h4>
      <div class="only-mobile">${byCat(c.id).map(productCardAdmin).join('')}</div>
      <div class="only-desktop table-wrap">
        <table>
          <thead><tr><th>Article</th><th>Description</th><th>Prix</th><th>État</th><th style="text-align:right">Actions</th></tr></thead>
          <tbody>
            ${byCat(c.id).map((p) => `
              <tr data-p="${p.id}">
                <td>
                  <div class="row">
                    <img src="${prodImg(p.img)}" alt="" style="width:38px;height:38px;object-fit:contain;border-radius:8px;background:var(--blue-050);padding:3px">
                    <strong>${esc(p.name)}</strong>
                  </div>
                </td>
                <td class="small muted">${esc(p.description || '—')}</td>
                <td>
                  <div class="row" style="gap:6px">
                    <input class="input mono" type="number" step="0.5" min="0" style="width:96px;min-height:40px;padding:6px 10px" value="${(p.price / 100).toFixed(2)}" data-price="${p.id}" aria-label="Prix de ${esc(p.name)}">
                    <span class="small muted">€</span>
                  </div>
                </td>
                <td><span class="pill ${p.available ? 'ok' : 'grey'}">${p.available ? 'En vente' : 'Retiré'}</span></td>
                <td style="text-align:right;white-space:nowrap">
                  <button class="btn btn-xs btn-outline" data-toggle="${p.id}">${p.available ? 'Retirer' : 'Remettre en vente'}</button>
                  <button class="btn btn-xs btn-outline" data-edit="${p.id}">${ic('edit')}</button>
                  <button class="btn btn-xs btn-danger" data-del="${p.id}">${ic('trash')}</button>
                </td>
              </tr>`).join('')}
          </tbody>
        </table>
      </div>`).join('')}`;

  el.querySelector('#newProduct').addEventListener('click', () => productSheet(root, null));
  el.querySelectorAll('[data-edit]').forEach((b) => b.addEventListener('click', () => productSheet(root, state.products.find((p) => p.id === b.dataset.edit))));
  el.querySelectorAll('[data-toggle]').forEach((b) => b.addEventListener('click', async () => {
    const p = state.products.find((x) => x.id === b.dataset.toggle);
    try {
      await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { available: !p.available });
      toast(p.available ? `${p.name} retiré de la vente.` : `${p.name} remis en vente.`, 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
  el.querySelectorAll('[data-del]').forEach((b) => b.addEventListener('click', async () => {
    const p = state.products.find((x) => x.id === b.dataset.del);
    if (!confirm(`Supprimer définitivement « ${p.name} » ?\n\nPour le retirer temporairement, utilisez plutôt « Retirer ».`)) return;
    try {
      await api.del(`/api/admin/products/${encodeURIComponent(p.id)}`);
      toast('Article supprimé.');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
  // prix : validation à la sortie du champ
  el.querySelectorAll('[data-price]').forEach((input) => {
    const save = async () => {
      const p = state.products.find((x) => x.id === input.dataset.price);
      const cents = Math.round(Number(String(input.value).replace(',', '.')) * 100);
      if (!Number.isFinite(cents) || cents < 0) { input.value = (p.price / 100).toFixed(2); toast('Prix invalide.', 'err'); return; }
      if (cents === p.price) return;
      try {
        await api.put(`/api/admin/products/${encodeURIComponent(p.id)}`, { price: cents });
        p.price = cents;
        toast(`${p.name} : ${euro(cents)}`, 'ok');
      } catch (err) { toast(err.message, 'err'); input.value = (p.price / 100).toFixed(2); }
    };
    input.addEventListener('change', save);
    input.addEventListener('blur', save);
    input.addEventListener('keydown', (e) => { if (e.key === 'Enter') { e.preventDefault(); input.blur(); } });
  });
}

/* ——— Images personnalisées des produits ————————————————————————
   - SVG : nettoyé (scripts retirés) puis encodé tel quel en « data:… ».
   - Photos PNG/JPEG : ouvertes dans le petit éditeur de cadrage
     ci-dessous (placement au doigt, zoom, rotation) sur le fond gris
     du site (#F4F5FF, comme les illustrations maison), export 512×512. */
async function fichierSvgVersDataUri(fichier) {
  if (fichier.size > 300 * 1024) throw new Error('Ce SVG est trop lourd (300 Ko maximum).');
  let texte = await fichier.text();
  texte = texte
    .replace(/<script[\s\S]*?<\/script>/gi, '')
    .replace(/\son[a-z]+\s*=\s*"[^"]*"/gi, '')
    .replace(/\son[a-z]+\s*=\s*'[^']*'/gi, '');
  const octets = new TextEncoder().encode(texte);
  let binaire = '';
  octets.forEach((o) => { binaire += String.fromCharCode(o); });
  return 'data:image/svg+xml;base64,' + btoa(binaire);
}

/* Décode un fichier photo et le limite à 1536 px (net même en zoomant,
   sans faire souffrir le téléphone). Renvoie une source dessinable. */
async function chargerPhoto(fichier) {
  let bitmap = null;
  if (window.createImageBitmap) {
    try { bitmap = await createImageBitmap(fichier, { imageOrientation: 'from-image' }); }
    catch { try { bitmap = await createImageBitmap(fichier); } catch { bitmap = null; } }
  }
  if (!bitmap) {
    bitmap = await new Promise((resoudre, rejeter) => {
      const img = new Image();
      img.onload = () => resoudre(img);
      img.onerror = () => rejeter(new Error('Image illisible.'));
      img.src = URL.createObjectURL(fichier);
    });
  }
  const L = bitmap.width || bitmap.naturalWidth;
  const H = bitmap.height || bitmap.naturalHeight;
  const e = Math.min(1, 1536 / Math.max(L, H));
  if (e >= 1) return bitmap;
  const c = document.createElement('canvas');
  c.width = Math.max(1, Math.round(L * e));
  c.height = Math.max(1, Math.round(H * e));
  c.getContext('2d').drawImage(bitmap, 0, 0, c.width, c.height);
  return c;
}

/* Décode une image déjà enregistrée (data:…) pour pouvoir la recadrer. */
function chargerDepuisUri(uri) {
  return new Promise((resoudre, rejeter) => {
    const img = new Image();
    img.onload = () => resoudre(img);
    img.onerror = rejeter;
    img.src = uri;
  });
}

/* ——— Petit éditeur de cadrage ————————————————————————————————————
   La photo se déplace au doigt (ou à la souris) dans le carré, se
   zoome (curseur, molette ou pincement) et pivote. Le fond gris du
   site remplit les zones vides ; ce qui dépasse du cadre est coupé. */
const CADRE_FOND = '#F4F5FF';
function creerEditeurCadrage(toile) {
  const ctx = toile.getContext('2d');
  const T = toile.width;
  let source = null, sw = 0, sh = 0;
  let zoom = 1, rotation = 0, dx = 0, dy = 0;
  let rappel = null;

  const echelleBase = () => Math.min(T / sw, T / sh);
  const bornerZoom = (z) => Math.max(0.5, Math.min(6, z));

  function dessiner() {
    ctx.fillStyle = CADRE_FOND;
    ctx.fillRect(0, 0, T, T);
    if (source) {
      ctx.save();
      ctx.translate(T / 2 + dx, T / 2 + dy);
      ctx.rotate(rotation * Math.PI / 180);
      const e = echelleBase() * zoom;
      ctx.scale(e, e);
      ctx.drawImage(source, -sw / 2, -sh / 2);
      ctx.restore();
    }
    if (rappel) rappel();
  }

  const pointeurs = new Map();
  let distPince = 0;
  toile.addEventListener('pointerdown', (ev) => {
    try { toile.setPointerCapture(ev.pointerId); } catch { /* pointeur déjà relâché */ }
    pointeurs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pointeurs.size === 2) {
      const [a, b] = [...pointeurs.values()];
      distPince = Math.hypot(a.x - b.x, a.y - b.y);
    }
  });
  toile.addEventListener('pointermove', (ev) => {
    if (!source || !pointeurs.has(ev.pointerId)) return;
    const avant = pointeurs.get(ev.pointerId);
    pointeurs.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pointeurs.size === 1) {
      const k = T / toile.getBoundingClientRect().width;
      dx = Math.max(-T, Math.min(T, dx + (ev.clientX - avant.x) * k));
      dy = Math.max(-T, Math.min(T, dy + (ev.clientY - avant.y) * k));
      dessiner();
    } else if (pointeurs.size === 2) {
      const [a, b] = [...pointeurs.values()];
      const d = Math.hypot(a.x - b.x, a.y - b.y);
      if (distPince > 0) { zoom = bornerZoom(zoom * d / distPince); dessiner(); }
      distPince = d;
    }
  });
  const finPointeur = (ev) => { pointeurs.delete(ev.pointerId); if (pointeurs.size < 2) distPince = 0; };
  toile.addEventListener('pointerup', finPointeur);
  toile.addEventListener('pointercancel', finPointeur);
  toile.addEventListener('wheel', (ev) => {
    if (!source) return;
    ev.preventDefault();
    zoom = bornerZoom(zoom * (ev.deltaY < 0 ? 1.08 : 1 / 1.08));
    dessiner();
  }, { passive: false });

  return {
    charger(img) {
      source = img;
      sw = img.width || img.naturalWidth;
      sh = img.height || img.naturalHeight;
      zoom = 1; rotation = 0; dx = 0; dy = 0;
      dessiner();
    },
    fermer() { source = null; dessiner(); },
    actif: () => !!source,
    recentrer() { zoom = 1; rotation = 0; dx = 0; dy = 0; dessiner(); },
    zoom: () => zoom,
    definirZoom(z) { zoom = bornerZoom(z); dessiner(); },
    rotation: () => rotation,
    definirRotation(d) { rotation = ((d % 360) + 360) % 360; dessiner(); },
    surChangement(fn) { rappel = fn; },
    exporter() {
      let uri = toile.toDataURL('image/webp', 0.85);
      if (!uri.startsWith('data:image/webp')) uri = toile.toDataURL('image/jpeg', 0.85);
      return uri;
    },
  };
}

function productSheet(root, product) {
  const isNew = !product;
  /* Image personnalisée déjà enregistrée sur ce produit (data:image/…). */
  const imgPersoInitiale = (typeof product?.img === 'string' && product.img.startsWith('data:image/')) ? product.img : '';
  ui.sheet.open({
    title: isNew ? 'Nouvel article' : `Modifier ${product.name}`,
    body: `
      <label class="field"><span class="label">Nom</span>
        <input class="input" id="pName" value="${esc(product?.name || '')}" placeholder="Glace pistache"></label>
      <label class="field"><span class="label">Description courte</span>
        <input class="input" id="pDesc" maxlength="120" value="${esc(product?.description || '')}" placeholder="Crème glacée pistache de Sicile"></label>
      <div class="row" style="gap:12px;align-items:flex-start">
        <label class="field grow"><span class="label">Prix (€)</span>
          <input class="input mono" id="pPrice" type="number" step="0.5" min="0" value="${((product?.price ?? 350) / 100).toFixed(2)}"></label>
        <label class="field grow"><span class="label">Catégorie</span>
          <select class="select" id="pCat">
            ${state.categories.map((c) => `<option value="${c.id}" ${product?.catId === c.id ? 'selected' : ''}>${esc(c.name)}</option>`).join('')}
          </select></label>
      </div>
      <label class="field"><span class="label">Illustration</span>
        <select class="select" id="pImg">
          <option value="__perso__" ${imgPersoInitiale ? 'selected' : 'hidden'}>★ Votre image personnalisée</option>
          ${IMG_CHOICES.map((i) => `<option value="${i}" ${product?.img === i ? 'selected' : ''}>${i.replace('.svg', '')}</option>`).join('')}
        </select>
        <span class="hint">Choisissez l’illustration la plus proche du produit.</span></label>
      <div class="field">
        <span class="label">Ou votre propre image</span>
        <div class="row" style="gap:12px;align-items:center">
          <img id="pImgApercu" alt="" style="width:64px;height:64px;object-fit:contain;border-radius:12px;background:var(--blue-050);padding:4px">
          <div class="grow">
            <button type="button" class="btn btn-outline btn-xs" id="pImgBtn">${ic('image')} Choisir mon image…</button>
            <button type="button" class="btn btn-outline btn-xs" id="pImgReset" hidden>Retirer</button>
            <div class="hint" id="pImgInfo" style="margin-top:6px">PNG, JPEG ou SVG — elle sera optimisée automatiquement pour le site.</div>
          </div>
        </div>
        <div id="pCadrage" hidden>
          <canvas id="pToile" class="cadre-toile" width="512" height="512"></canvas>
          <div class="cadre-controles">
            <div class="cadre-ligne">
              <span class="label-mini">Zoom</span>
              <input type="range" id="pZoom" min="0.5" max="6" step="0.01" value="1">
            </div>
            <div class="cadre-ligne">
              <span class="label-mini">Rotation</span>
              <button type="button" class="btn btn-outline btn-xs" id="pRotG" aria-label="Pivoter à gauche">↺ 90°</button>
              <input type="range" id="pRot" min="-180" max="180" step="1" value="0">
              <button type="button" class="btn btn-outline btn-xs" id="pRotD" aria-label="Pivoter à droite">90° ↻</button>
            </div>
            <div class="cadre-ligne">
              <button type="button" class="btn btn-outline btn-xs" id="pRecentrer">Recentrer</button>
              <span class="hint" style="margin:0">Glissez la photo dans le cadre gris : ce qui dépasse sera coupé.</span>
            </div>
          </div>
        </div>
        <input type="file" id="pImgFile" accept="image/png,image/jpeg,image/svg+xml,.png,.jpg,.jpeg,.svg" hidden>
      </div>
      <label class="switch"><input type="checkbox" id="pAvail" ${product?.available !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Proposé à la vente</span></label>
      <div id="pErr" class="mt-2"></div>`,
    foot: `<button class="btn" id="pSave">${isNew ? 'AJOUTER L’ARTICLE' : 'ENREGISTRER'}</button>`,
    onMount(body, foot) {
      /* ---- Image personnalisée (PNG / JPEG / SVG) ---- */
      const selImg = body.querySelector('#pImg');
      const apercu = body.querySelector('#pImgApercu');
      const info = body.querySelector('#pImgInfo');
      const btnReset = body.querySelector('#pImgReset');
      const entreeFichier = body.querySelector('#pImgFile');
      const blocCadrage = body.querySelector('#pCadrage');
      const editeur = creerEditeurCadrage(body.querySelector('#pToile'));
      const zoomEl = body.querySelector('#pZoom');
      const rotEl = body.querySelector('#pRot');
      const INFO_BASE = 'PNG, JPEG ou SVG — elle sera optimisée automatiquement pour le site.';
      let imgPerso = imgPersoInitiale;

      const majApercu = () => {
        const photo = editeur.actif();
        blocCadrage.hidden = !photo;
        apercu.style.display = photo ? 'none' : '';
        if (!photo) apercu.src = imgPerso || prodImg(selImg.value === '__perso__' ? '' : selImg.value);
        btnReset.hidden = !(photo || imgPerso);
      };
      const majControles = () => {
        zoomEl.value = editeur.zoom();
        rotEl.value = ((editeur.rotation() + 180) % 360) - 180;
      };
      editeur.surChangement(majControles);
      zoomEl.addEventListener('input', () => editeur.definirZoom(Number(zoomEl.value)));
      rotEl.addEventListener('input', () => editeur.definirRotation(Number(rotEl.value)));
      body.querySelector('#pRotG').addEventListener('click', () => editeur.definirRotation(editeur.rotation() - 90));
      body.querySelector('#pRotD').addEventListener('click', () => editeur.definirRotation(editeur.rotation() + 90));
      body.querySelector('#pRecentrer').addEventListener('click', () => editeur.recentrer());

      selImg.addEventListener('change', () => {
        if (selImg.value !== '__perso__') {
          imgPerso = '';
          editeur.fermer();
          info.textContent = INFO_BASE;
        }
        majApercu();
      });
      body.querySelector('#pImgBtn').addEventListener('click', () => entreeFichier.click());
      btnReset.addEventListener('click', () => {
        imgPerso = '';
        editeur.fermer();
        selImg.querySelector('option[value="__perso__"]').hidden = true;
        if (selImg.value === '__perso__') selImg.selectedIndex = 1;
        info.textContent = INFO_BASE;
        majApercu();
      });
      entreeFichier.addEventListener('change', async () => {
        const fichier = entreeFichier.files?.[0];
        entreeFichier.value = '';
        if (!fichier) return;
        if (!['image/png', 'image/jpeg', 'image/svg+xml'].includes(fichier.type)) {
          toast('Format non accepté : choisis une image PNG, JPEG ou SVG.', 'err');
          return;
        }
        info.textContent = 'Préparation de l’image…';
        try {
          selImg.querySelector('option[value="__perso__"]').hidden = false;
          selImg.value = '__perso__';
          if (fichier.type === 'image/svg+xml') {
            /* SVG : import direct (vectoriel), pas besoin de cadrage. */
            editeur.fermer();
            imgPerso = await fichierSvgVersDataUri(fichier);
            info.textContent = `${fichier.name} prêt. Pensez à enregistrer !`;
          } else {
            /* Photo : ouverture du petit éditeur de cadrage. */
            imgPerso = '';
            editeur.charger(await chargerPhoto(fichier));
            info.textContent = `${fichier.name} : placez la photo dans le cadre, puis enregistrez.`;
          }
          majApercu();
        } catch (err) {
          info.textContent = INFO_BASE;
          toast(err.message, 'err');
        }
      });

      /* Produit qui a déjà une photo perso : on la rouvre dans l'éditeur
         pour pouvoir la recadrer. (Les SVG restent en aperçu simple.) */
      if (imgPersoInitiale && !imgPersoInitiale.startsWith('data:image/svg')) {
        chargerDepuisUri(imgPersoInitiale)
          .then((img) => { editeur.charger(img); imgPerso = ''; majApercu(); })
          .catch(() => {});
      }
      majApercu();

      foot.querySelector('#pSave').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        const errBox = body.querySelector('#pErr');
        const payload = {
          name: body.querySelector('#pName').value.trim(),
          description: body.querySelector('#pDesc').value.trim(),
          price: Math.round(Number(String(body.querySelector('#pPrice').value).replace(',', '.')) * 100),
          catId: body.querySelector('#pCat').value,
          img: (editeur.actif() ? editeur.exporter() : imgPerso) || body.querySelector('#pImg').value,
          available: body.querySelector('#pAvail').checked,
        };
        if (payload.name.length < 2) { errBox.innerHTML = '<div class="banner banner-error">Nom trop court.</div>'; return; }
        if (!Number.isFinite(payload.price) || payload.price < 0) { errBox.innerHTML = '<div class="banner banner-error">Prix invalide.</div>'; return; }
        if (!payload.img || payload.img === '__perso__') { errBox.innerHTML = '<div class="banner banner-error">Choisissez une illustration ou envoyez votre propre image.</div>'; return; }
        btn.disabled = true;
        btn.innerHTML = '<span class="spin"></span>';
        try {
          if (isNew) await api.post('/api/admin/products', payload);
          else await api.put(`/api/admin/products/${encodeURIComponent(product.id)}`, payload);
          toast(isNew ? 'Article ajouté.' : 'Article enregistré.', 'ok');
          ui.sheet.close();
          await refresh(root, { silent: true });
          /* Image personnalisée : on vérifie que le serveur l'a bien conservée
             (certains hébergements jettent les valeurs qu'ils ne connaissent pas). */
          if (payload.img.startsWith('data:image/')) {
            const retrouve = (state.products || []).find((p) => isNew ? p.name === payload.name : p.id === product.id);
            if (!retrouve || retrouve.img !== payload.img) {
              toast('Article enregistré, MAIS ton serveur n’a pas conservé l’image personnalisée. Envoie-moi les fichiers PHP du site et je corrige ça définitivement.', 'err');
            } else {
              toast('Image personnalisée bien enregistrée ✓', 'ok');
            }
          }
        } catch (err) {
          errBox.innerHTML = `<div class="banner banner-error">${esc(err.message)}</div>`;
          btn.disabled = false;
          btn.textContent = isNew ? 'AJOUTER L’ARTICLE' : 'ENREGISTRER';
        }
      });
    },
  });
}

function productCardAdmin(p) {
  return `
  <article class="prod-card">
    <div class="top">
      <img src="${prodImg(p.img)}" alt="">
      <div class="grow">
        <div class="nm">${esc(p.name)}</div>
        <div class="ds">${esc(p.description || '—')}</div>
      </div>
      <span class="pill ${p.available ? 'ok' : 'grey'}">${p.available ? 'En vente' : 'Retiré'}</span>
    </div>
    <div class="price-row">
      <span class="label" style="margin:0">Prix</span>
      <input class="input mono" type="number" step="0.5" min="0" value="${(p.price / 100).toFixed(2)}" data-price="${p.id}" aria-label="Prix de ${esc(p.name)}">
      <span class="strong">€</span>
    </div>
    <div class="acts">
      <button class="btn btn-sm btn-outline" data-toggle="${p.id}">${p.available ? 'Retirer de la vente' : 'Remettre en vente'}</button>
      <button class="btn btn-sm btn-outline" data-edit="${p.id}">${ic('edit')} Modifier</button>
      <button class="btn btn-sm btn-danger" data-del="${p.id}">${ic('trash')}</button>
    </div>
  </article>`;
}

const IMG_CHOICES = [
  'glace-corne.svg', 'glace-pot.svg', 'coupe.svg', 'batonnet.svg',
  'eau.svg', 'soda.svg', 'limonade.svg', 'jus.svg', 'biere.svg', 'cafe.svg',
  'salade.svg', 'panini.svg', 'frites.svg', 'crepe.svg', 'cookie.svg', 'fruits.svg',
];

/* ================================================================= LIVREURS = */
function paintCouriers(root, el) {
  el.innerHTML = `
    <div class="row-between mb-2">
      <div>
        <h3 class="mb-0">Équipe de livraison</h3>
        <p class="small muted mb-0">Ajoutez les livreurs, activez-les ou désactivez-les. Chacun se connecte avec son propre compte.</p>
      </div>
      <button class="btn btn-sm" id="newCourier">${ic('plus')} Ajouter un livreur</button>
    </div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>Livreur</th><th>Contact</th><th>État</th><th>Activité</th><th style="text-align:right">Actions</th></tr></thead>
        <tbody>
          ${state.couriers.map((c) => `
            <tr>
              <td><strong>${esc(c.name)}</strong><br><span class="small muted">${esc(c.email)}</span></td>
              <td class="small">${esc(c.phone || '—')}<br><span class="small muted">${c.lastPos ? `position ${heureSec(c.lastPos.at)}` : 'position inconnue'}</span></td>
              <td>
                <span class="pill ${c.online ? 'ok' : 'grey'}">${c.online ? 'En service' : 'Hors service'}</span>
                ${c.active ? '' : '<span class="pill warn">désactivé</span>'}
              </td>
              <td class="small">${c.activeOrders} en cours<br><span class="muted">${c.delivered} livrées</span></td>
              <td style="text-align:right;white-space:nowrap">
                <button class="btn btn-xs btn-outline" data-cedit="${c.id}">${ic('edit')}</button>
                ${c.lastPos ? `<a class="btn btn-xs btn-ghost" target="_blank" rel="noopener" href="${mapsLink(c.lastPos)}">${ic('pin')}</a>` : ''}
                <button class="btn btn-xs btn-danger" data-cdel="${c.id}">${esc(c.active ? 'Désactiver' : 'Activer')}</button>
              </td>
            </tr>`).join('')}
        </tbody>
      </table>
    </div>
    <p class="small muted mt-2">L’assignation automatique envoie chaque nouvelle commande au livreur en service le moins chargé. Un livreur avec une livraison en cours ne peut pas être supprimé — il est simplement désactivé.</p>`;

  el.querySelector('#newCourier').addEventListener('click', () => courierSheet(root, null));
  el.querySelectorAll('[data-cedit]').forEach((b) => b.addEventListener('click', () => courierSheet(root, state.couriers.find((c) => c.id === b.dataset.cedit))));
  el.querySelectorAll('[data-cdel]').forEach((b) => b.addEventListener('click', async () => {
    const c = state.couriers.find((x) => x.id === b.dataset.cdel);
    const turningOff = c.active;
    if (turningOff && !confirm(`Désactiver ${c.name} ?\nSon compte ne pourra plus se connecter.`)) return;
    try {
      if (turningOff) await api.put(`/api/admin/couriers/${encodeURIComponent(c.id)}`, { active: false, online: false });
      else await api.put(`/api/admin/couriers/${encodeURIComponent(c.id)}`, { active: true });
      toast(turningOff ? 'Livreur désactivé.' : 'Livreur réactivé.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
  }));
}

function courierSheet(root, courier) {
  const isNew = !courier;
  ui.sheet.open({
    title: isNew ? 'Nouveau livreur' : `Modifier ${courier.name}`,
    body: `
      <label class="field"><span class="label">Prénom / nom</span><input class="input" id="cName" value="${esc(courier?.name || '')}" placeholder="Léo"></label>
      <label class="field"><span class="label">Email de connexion</span><input class="input" id="cEmail" type="email" value="${esc(courier?.email || '')}" placeholder="livreur@pannacottaclub.fr"></label>
      <label class="field"><span class="label">Téléphone</span><input class="input" id="cPhone" value="${esc(courier?.phone || '')}" placeholder="06 12 34 56 78"></label>
      <label class="field"><span class="label">${isNew ? 'Mot de passe' : 'Nouveau mot de passe (laisser vide pour conserver)'}</span>
        <input class="input" id="cPass" type="text" value="" placeholder="6 caractères minimum"></label>
      ${isNew ? '' : `<label class="switch"><input type="checkbox" id="cActive" ${courier.active !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Compte actif</span></label>`}
      <div id="cErr" class="mt-2"></div>`,
    foot: `<button class="btn" id="cSave">${isNew ? 'CRÉER LE COMPTE' : 'ENREGISTRER'}</button>`,
    onMount(body, foot) {
      foot.querySelector('#cSave').addEventListener('click', async (e) => {
        const btn = e.currentTarget;
        const errBox = body.querySelector('#cErr');
        const payload = {
          name: body.querySelector('#cName').value.trim(),
          email: body.querySelector('#cEmail').value.trim(),
          phone: body.querySelector('#cPhone').value.trim(),
          password: body.querySelector('#cPass').value,
        };
        if (!isNew && !payload.password) delete payload.password;
        if (!isNew) payload.active = body.querySelector('#cActive').checked;
        if (payload.name.length < 2) { errBox.innerHTML = '<div class="banner banner-error">Nom trop court.</div>'; return; }
        if (isNew && payload.password.length < 6) { errBox.innerHTML = '<div class="banner banner-error">Mot de passe : 6 caractères minimum.</div>'; return; }
        btn.disabled = true;
        btn.innerHTML = '<span class="spin"></span>';
        try {
          if (isNew) await api.post('/api/admin/couriers', payload);
          else await api.put(`/api/admin/couriers/${encodeURIComponent(courier.id)}`, payload);
          toast(isNew ? 'Compte livreur créé.' : 'Livreur enregistré.', 'ok');
          ui.sheet.close();
          await refresh(root, { silent: true });
        } catch (err) {
          errBox.innerHTML = `<div class="banner banner-error">${esc(err.message)}</div>`;
          btn.disabled = false;
          btn.textContent = isNew ? 'CRÉER LE COMPTE' : 'ENREGISTRER';
        }
      });
    },
  });
}

/* ============================================================ PANNEAUX & QR = */
/* Coordonnées des escaliers : modifiables ci-dessous. Elles sont gravées
   DANS les QR codes imprimés (?ac=…&la=…&lo=…) : aucun réglage serveur
   n'est nécessaire, le panneau transporte lui-même la bonne position. */
const CLE_COORDS_ACCES = 'pc-acces-coord.v1';

function accesCoordonnees() {
  const sur = LS.get(CLE_COORDS_ACCES, {});
  return ACCES_DIGUE.map((a) => {
    /* Chaque coordonnée peut être modifiée séparément : on part des valeurs
       d'origine et on applique ce qui a été saisi. */
    const o = sur[a.n] || {};
    const lat = Number(o.lat);
    const lng = Number(o.lng);
    return {
      n: a.n,
      lat: Number.isFinite(lat) ? lat : a.lat,
      lng: Number.isFinite(lng) ? lng : a.lng,
      perso: Number.isFinite(lat) || Number.isFinite(lng),
    };
  });
}

function paintQr(root, el) {
  const base = String(state.publicUrl || location.origin + BASE).replace(/\/$/, '');
  const ACCES = accesCoordonnees();
  const urlPour = (a) => `${base}/commander?ac=${a.n}&la=${a.lat}&lo=${a.lng}`;

  el.innerHTML = `
    <div class="row-between mb-2">
      <div>
        <h3 class="mb-0">Panneaux QR — escaliers de la digue</h3>
        <p class="small muted mb-0" style="margin-top:4px">Chaque escalier a <strong>son</strong> QR code : quand un client le scanne, le site sait déjà à quel escalier il se trouve (aucun GPS demandé) et le livreur reçoit l'information sur la commande.</p>
      </div>
      <div class="btn-row">
        <button class="btn btn-sm btn-outline" id="qrAll">${ic('qr')} Imprimer les 11 panneaux</button>
        <button class="btn btn-sm btn-ghost" id="qrReset">Coordonnées d'origine</button>
      </div>
    </div>
    <div class="qr-grid" id="qrGrid">
      ${ACCES.map((a) => `
        <div class="card qr-card" data-url="${esc(urlPour(a))}">
          <div class="qr-thumb" id="qrT${a.n}"></div>
          <strong>Escalier n°${a.n}</strong>
          <div class="qr-coords">
            <label class="small">Lat<input class="input" data-coord-lat="${a.n}" value="${a.lat}" inputmode="decimal" autocomplete="off"></label>
            <label class="small">Lng<input class="input" data-coord-lng="${a.n}" value="${a.lng}" inputmode="decimal" autocomplete="off"></label>
          </div>
          ${a.perso ? '<span class="small" style="color:var(--blue);font-weight:800">✓ coordonnées modifiées</span>' : ''}
          <div class="btn-row" style="justify-content:center">
            <button class="btn btn-xs btn-outline" data-qr-png="${a.n}">PNG</button>
            <button class="btn btn-xs btn-outline" data-qr-print="${a.n}">Imprimer</button>
          </div>
        </div>`).join('')}
    </div>`;

  /** Dessine un QR code (librairie MIT embarquée, tout se passe en local). */
  const dessiner = (conteneur, valeur, px) => {
    if (!conteneur) return;
    if (typeof qrcode !== 'function') { conteneur.innerHTML = '<p class="small muted">QR indisponible</p>'; return; }
    try {
      const qr = qrcode(0, 'M');
      qr.addData(valeur);
      qr.make();
      conteneur.innerHTML = qr.createImgTag(4, 8);
      const img = conteneur.querySelector('img');
      if (img) { img.style.width = `${px}px`; img.style.height = `${px}px`; img.alt = 'QR code'; }
    } catch { conteneur.innerHTML = '<p class="small muted">QR indisponible</p>'; }
  };
  for (const a of ACCES) dessiner(el.querySelector(`#qrT${a.n}`), urlPour(a), 150);

  /* Modification d'une coordonnée : enregistrée puis QR regénéré aussitôt. */
  const sauverCoord = (input, cle) => {
    const n = Number(input.dataset[cle === 'lat' ? 'coordLat' : 'coordLng']);
    const v = parseFloat(String(input.value).replace(',', '.'));
    if (!Number.isFinite(v) || v < -90 || v > 90) { toast('Coordonnée invalide — exemple : 49.290414', 'err'); return; }
    const tous = LS.get(CLE_COORDS_ACCES, {});
    tous[n] = { ...(tous[n] || {}), [cle]: v };
    LS.set(CLE_COORDS_ACCES, tous);
    toast(`Escalier n°${n} : coordonnée enregistrée, QR code regénéré.`, 'ok');
    paintQr(root, el);
  };
  el.querySelectorAll('[data-coord-lat]').forEach((i) => i.addEventListener('change', () => sauverCoord(i, 'lat')));
  el.querySelectorAll('[data-coord-lng]').forEach((i) => i.addEventListener('change', () => sauverCoord(i, 'lng')));

  el.querySelector('#qrReset').addEventListener('click', () => {
    if (!confirm("Restaurer les coordonnées d'origine des 11 escaliers ? (Les QR déjà imprimés restent valables.)")) return;
    LS.del(CLE_COORDS_ACCES);
    paintQr(root, el);
  });

  /** Convertit l'image QR en vrai PNG téléchargeable (haute résolution). */
  const enPng = (img) => new Promise((resoudre) => {
    const c = document.createElement('canvas');
    c.width = (img.naturalWidth || 200) * 3;
    c.height = (img.naturalHeight || 200) * 3;
    const ctx = c.getContext('2d');
    ctx.imageSmoothingEnabled = false;
    const fini = () => { ctx.drawImage(img, 0, 0, c.width, c.height); resoudre(c.toDataURL('image/png')); };
    if (img.complete) fini(); else img.onload = fini;
  });

  el.querySelectorAll('[data-qr-png]').forEach((b) => b.addEventListener('click', async () => {
    const img = el.querySelector(`#qrT${b.dataset.qrPng} img`);
    if (!img) return;
    const a = document.createElement('a');
    a.href = await enPng(img);
    a.download = `pannacottaclub-escalier-${b.dataset.qrPng}.png`;
    a.click();
    toast(`QR de l'escalier n°${b.dataset.qrPng} téléchargé.`, 'ok');
  }));

  /** La fiche à plastifier pour un escalier (HTML autonome, prête à imprimer). */
  const ficheHtml = (n) => {
    const url = urlPour(accesCoordonnees().find((a) => a.n === n));
    let qr = '';
    if (typeof qrcode === 'function') {
      const q = qrcode(0, 'M');
      q.addData(url);
      q.make();
      qr = q.createImgTag(8, 16);
    }
    return `
    <div class="fiche">
      <div class="marque">PANNACOTTACLUB · CABOURG · PLAGE</div>
      <h1>Scannez, commandez,<br>on vous livre sur le sable</h1>
      <div class="qr">${qr}</div>
      <div class="num">ESCALIER N°${n}</div>
      <p class="petit">Glaces · Boissons · Confiseries<br>Paiement à la livraison — plage entre les postes de secours 1 et 2</p>
    </div>`;
  };

  const styleFiches = `
    <style>
      body { margin:0; font-family: system-ui, sans-serif; background:#fff; color:#090A33; }
      .fiche { min-height:96vh; display:flex; flex-direction:column; align-items:center;
        justify-content:center; text-align:center; padding:30px 40px; box-sizing:border-box;
        border:8px solid #060CD4; border-radius:32px; margin:14px; page-break-after:always; }
      .marque { font-weight:900; letter-spacing:.22em; color:#060CD4; font-size:15px; }
      .fiche h1 { font-size:40px; line-height:1.15; margin:18px 0 10px; }
      .fiche .qr img { width:330px; height:330px; }
      .fiche .num { font-size:58px;font-weight:900;color:#060CD4;letter-spacing:.04em;margin:14px 0 6px;border:4px solid #060CD4;border-radius:18px;padding:6px 30px; }
      .fiche .petit { font-size:17px; line-height:1.5; color:#4A4E79; }
      @media print { .fiche { border-radius:24px; margin:0; min-height:97vh; } }
    </style>`;

  const ouvrirFiches = (liste) => {
    const w = window.open('', '_blank');
    if (!w) { toast('Autorisez les fenêtres pop-up pour imprimer.', 'err'); return; }
    const logo = new URL('assets/img/logo.png', location.href).href;
    w.document.write(`<!doctype html><html lang="fr"><head><meta charset="utf-8">
      <title>PannacottaClub — panneaux escaliers</title>
      ${styleFiches}</head><body>
      ${liste.map(ficheHtml).join('')}
      <script>window.onload = () => setTimeout(() => window.print(), 400);<\/script>
      </body></html>`);
    w.document.close();
  };

  el.querySelector('#qrAll').addEventListener('click', () => ouvrirFiches(ACCES_DIGUE.map((a) => a.n)));
  el.querySelectorAll('[data-qr-print]').forEach((b) => b.addEventListener('click', () => ouvrirFiches([Number(b.dataset.qrPrint)])));
}

/* ================================================================ RÉGLAGES = */
function paintSettings(root, el) {
  const s = state.settings;
  el.innerHTML = `
    <div class="grid-2">
      <div class="card">
        <div class="card-head"><h3>Exploitation</h3></div>
        <label class="switch mb-2"><input type="checkbox" id="sAccept" ${s.acceptingOrders ? 'checked' : ''}><span class="track"></span><span class="strong">Service ouvert aux commandes</span></label>
        <label class="switch mb-2"><input type="checkbox" id="sAuto" ${s.autoAssign ? 'checked' : ''}><span class="track"></span><span class="strong">Assignation automatique au livreur</span></label>
        <p class="small muted">Avec un seul livreur, l’assignation automatique évite l’étape « prendre la commande » : chaque commande lui est confiée dès sa validation.</p>
        <label class="switch"><input type="checkbox" id="sZoneReq" ${s.requireInZone ? 'checked' : ''}><span class="track"></span><span class="strong">Refuser les commandes hors zone</span></label>
        <label class="switch mt-2"><input type="checkbox" id="sLiveMap" ${s.liveMapPublic !== false ? 'checked' : ''}><span class="track"></span><span class="strong">Afficher le livreur en direct sur la page d'accueil</span></label>
        <p class="small muted" style="margin-top:6px">Position du livreur en direct, au mètre près, sans aucune donnée client, uniquement pendant une livraison. Décochez pour la garder privée.</p>
        <div class="divider"></div>
        <button class="btn btn-outline btn-sm" id="saveOps">Enregistrer</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>Carte Google</h3></div>
        <p class="small muted mb-2">Sans clé, le site affiche déjà la carte Google de la plage, recentrée sur la position exacte du livreur. Avec une clé Google Maps (« Maps JavaScript API »), vous obtenez la carte interactive : marqueurs qui glissent en direct, cercle de la zone de livraison et repères de vos lieux de vente.</p>
        <label class="field"><span class="label">Clé Google Maps (facultative)</span><input class="input mono" id="sGoogleKey" placeholder="AIza…" value="${esc(s.googleKey || '')}"></label>
        <p class="small muted">La clé reste chez vous. Restreignez-la par site web (référent HTTP) dans Google Cloud : elle est faite pour être visible dans le navigateur.</p>
        <button class="btn btn-outline btn-sm mt-2" id="saveGoogle">Enregistrer la clé</button>
      </div>

      <div class="card">
        <div class="card-head"><h3>Zone de livraison</h3></div>
        <label class="field"><span class="label">Libellé</span><input class="input" id="zLabel" value="${esc(s.zone?.label || '')}"></label>
        <div class="row" style="gap:12px">
          <label class="field grow"><span class="label">Latitude</span><input class="input mono" id="zLat" value="${s.zone?.lat ?? ''}"></label>
          <label class="field grow"><span class="label">Longitude</span><input class="input mono" id="zLng" value="${s.zone?.lng ?? ''}"></label>
        </div>
        <label class="field"><span class="label">Rayon (mètres)</span><input class="input mono" id="zRad" type="number" min="50" step="50" value="${s.zone?.radius ?? 900}"></label>
        <label class="field"><span class="label">Vitesse moyenne du livreur (m/s)</span><input class="input mono" id="sSpeed" type="number" step="0.1" min="0.5" value="${s.avgSpeed ?? 1.3}"></label>
        <button class="btn btn-outline btn-sm" id="saveZone">Enregistrer la zone</button>
        <p class="small muted mt-2">Astuce : récupérez les coordonnées du point de départ (poste de secours 1) sur maps.google.com, clic droit → « Plus d’infos sur cet endroit ».</p>
      </div>
    </div>`;

  el.querySelector('#saveOps').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      await api.put('/api/admin/settings', {
        acceptingOrders: el.querySelector('#sAccept').checked,
        autoAssign: el.querySelector('#sAuto').checked,
        requireInZone: el.querySelector('#sZoneReq').checked,
        liveMapPublic: el.querySelector('#sLiveMap').checked,
      });
      toast('Réglages enregistrés.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });

  el.querySelector('#saveGoogle').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      const rep = await api.put('/api/admin/settings', { googleKey: el.querySelector('#sGoogleKey').value.trim() });
      toast(rep.settings?.googleKey ? 'Clé Google Maps enregistrée.' : 'Clé retirée : carte Google intégrée.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });

  el.querySelector('#saveZone').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    btn.disabled = true;
    try {
      await api.put('/api/admin/settings', {
        avgSpeed: Number(el.querySelector('#sSpeed').value),
        zone: {
          label: el.querySelector('#zLabel').value.trim(),
          lat: Number(el.querySelector('#zLat').value),
          lng: Number(el.querySelector('#zLng').value),
          radius: Number(el.querySelector('#zRad').value),
        },
      });
      toast('Zone de livraison enregistrée.', 'ok');
      await refresh(root, { silent: true });
    } catch (err) { toast(err.message, 'err'); }
    btn.disabled = false;
  });
}

export function stopAdminLive() { liveStop?.(); liveStop = null; mapCtl?.destroy(); }
