/* ==========================================================================
   PANNACOTTACLUB — noyau applicatif
   API, état local, panier, temps réel (SSE), interface commune, icônes.
   ========================================================================== */

/* --------------------------------------------------------------- stockage */
const LS = {
  get(key, fallback) {
    try { const v = localStorage.getItem(key); return v ? JSON.parse(v) : fallback; }
    catch { return fallback; }
  },
  set(key, value) {
    try { localStorage.setItem(key, JSON.stringify(value)); } catch { /* mode privé */ }
  },
  del(key) { try { localStorage.removeItem(key); } catch { /* ignore */ } },
};

export const K = {
  cart: 'pc.cart.v1',
  orders: 'pc.orders.v1',       // commandes passées sur cet appareil (id + jeton de suivi)
  customer: 'pc.customer.v1',   // prénom + téléphone retenus
  tokens: 'pc.tokens.v1',       // jetons de session livreur / admin
  session: 'pc.session.v1',     // dernière session connue (réaffichée au démarrage)
  lastEmail: 'pc.email.v1',     // dernier email saisi (pré-remplissage à la reconnexion)
  acces: 'pc.acces.v1',         // escalier reconnu via le panneau QR scanné
};

/* --------------------------------------------------------------------- api */
/** Demande au serveur qui l'on est, d'après le cookie de session.
    Renvoie { user } si la session est valide, { offline: true } si le réseau
    ne répond pas, {} si le serveur dit clairement « personne ». */
let whoamiPromesse = null;
export async function whoami() {
  if (!whoamiPromesse) {
    const p = fetch(appUrl('/api/auth/me'), { credentials: 'same-origin', cache: 'no-store' })
      .then(async (r) => (r.status === 401 ? {} : r.ok ? await r.json().then((d) => (d && d.user ? { user: d.user } : {})).catch(() => ({})) : { offline: true }))
      .catch(() => ({ offline: true }))
      .finally(() => { setTimeout(() => { whoamiPromesse = null; }, 1500); });
    whoamiPromesse = p;
  }
  return whoamiPromesse;
}

/** Base du site : « / » à la racine du domaine, « /sous-dossier/ » sinon. */
export const BASE = (typeof window !== 'undefined' && window.PC_BASE) ? window.PC_BASE : '/';
/** Transforme « /api/menu » en adresse valable partout. */
export const appUrl = (path) => BASE.replace(/\/$/, '') + '/' + String(path).replace(/^\//, '');

export const api = {
  token: null,
  async call(path, { method = 'GET', body, signal, retry = true } = {}) {
    const headers = {};
    const target = appUrl(path);
    if (body !== undefined) headers['Content-Type'] = 'application/json';
    if (this.token) headers.Authorization = `Bearer ${this.token}`;
    let res;
    try {
      res = await fetch(target, {
        method,
        headers,
        body: body === undefined ? undefined : JSON.stringify(body),
        signal,
        credentials: 'same-origin',
      });
    } catch (err) {
      if (err?.name === 'AbortError') throw err;
      const netErr = new Error('Connexion impossible. Vérifiez votre réseau (4G/5G).');
      netErr.offline = true;
      throw netErr;
    }
    let data = null;
    const text = await res.text();
    try { data = text ? JSON.parse(text) : null; } catch { data = null; }
    if (res.status === 401) {
      // ATTENTION : un 401 ne veut pas dire « session expirée ». Le cookie de
      // session posé par le serveur (httpOnly, 90 jours) peut parfaitement être
      // valide alors que le jeton local a disparu — après un nettoyage du
      // navigateur, un changement d'appareil, ou si l'onglet est rouvert plus
      // tard. On demande donc au serveur QUI l'on est avant de déconnecter.
      const etat = await whoami();
      if (etat.user && retry) {
        // La session existe côté serveur : on reprend la main et on rejoue la requête.
        LS.set(K.session, etat.user);
        return this.call(path, { method, body, signal, retry: false });
      }
      if (!etat.user && !etat.offline) {
        // Le serveur confirme qu'il n'y a plus de session : on oublie le jeton mort.
        LS.del(K.tokens);
        LS.del(K.session);
        window.dispatchEvent(new CustomEvent('pc:session-lost'));
      }
    }
    if (!res.ok || (data && data.ok === false)) {
      const err = new Error(data?.error || `Erreur ${res.status}`);
      err.status = res.status;
      err.data = data;
      throw err;
    }
    return data || {};
  },
  get(p, opts) { return this.call(p, { ...opts }); },
  post(p, body, opts) { return this.call(p, { ...opts, method: 'POST', body: body || {} }); },
  put(p, body, opts) { return this.call(p, { ...opts, method: 'PUT', body: body || {} }); },
  del(p, opts) { return this.call(p, { ...opts, method: 'DELETE' }); },
};

/* -------------------------------------------------------------------- état */
export const store = {
  config: null,
  menu: { categories: [], products: [] },
  cart: LS.get(K.cart, { items: {}, updatedAt: 0 }),   // { productId: qty }
  session: null,                                        // { user, role }
  listeners: new Set(),

  cartCount() { return Object.values(this.cart.items).reduce((s, q) => s + q, 0); },
  cartLines() {
    const out = [];
    for (const [id, qty] of Object.entries(this.cart.items)) {
      const product = this.menu.products.find((p) => p.id === id);
      if (product && qty > 0) out.push({ product, qty });
    }
    return out;
  },
  cartSubtotal() { return this.cartLines().reduce((s, l) => s + l.product.price * l.qty, 0); },
  setQty(productId, qty) {
    const n = Math.max(0, Math.min(20, qty));
    if (n === 0) delete this.cart.items[productId];
    else this.cart.items[productId] = n;
    this.cart.updatedAt = Date.now();
    LS.set(K.cart, this.cart);
    this.emit('cart');
  },
  addQty(productId, delta = 1) { this.setQty(productId, (this.cart.items[productId] || 0) + delta); },
  clearCart() { this.cart = { items: {}, updatedAt: Date.now() }; LS.set(K.cart, this.cart); this.emit('cart'); },

  on(fn) { this.listeners.add(fn); return () => this.listeners.delete(fn); },
  emit(type, detail) { for (const fn of this.listeners) { try { fn(type, detail); } catch (e) { console.error(e); } } },
};

/* --------------------------------------------------------- commandes client */
export const myOrders = {
  all() { return LS.get(K.orders, []); },
  add(order, token) {
    const list = this.all().filter((o) => o.id !== order.id);
    list.unshift({ id: order.id, token, createdAt: order.createdAt, firstName: order.firstName || '', total: order.total, status: order.status });
    LS.set(K.orders, list.slice(0, 12));
  },
  update(id, patch) {
    const list = this.all().map((o) => (o.id === id ? { ...o, ...patch } : o));
    LS.set(K.orders, list);
  },
  last() { return this.all()[0] || null; },
  find(id) { return this.all().find((o) => o.id === id) || null; },
  clear() { LS.del(K.orders); },
};

/* ------------------------------------------------------------------ format */
export const euro = (cents) => `${(Math.round(cents || 0) / 100).toFixed(2).replace('.', ',')} €`;

/* Image d'un produit : soit un fichier du site (assets/img/prod/…), soit une
   image personnalisée envoyée depuis l'admin et stockée en « data:image/… »
   directement dans le champ img du produit. */
export const prodImg = (img) => (typeof img === 'string' && img.startsWith('data:image/'))
  ? img
  : `assets/img/prod/${esc(img || 'glace-corne.svg')}`;
export const heure = (ts) => (ts ? new Date(ts).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' }) : '—');
export const heureSec = (ts) => (ts ? new Date(ts).toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—');
export const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function distanceLabel(m) {
  if (m == null || !Number.isFinite(m)) return '';
  if (m < 1000) return `${Math.round(m / 5) * 5} m`;
  return `${(m / 1000).toFixed(1).replace('.', ',')} km`;
}

/* ------------------------------------------------------------------ icônes */
const ICONS = {
  cart: '<circle cx="9" cy="20" r="1.6"/><circle cx="18" cy="20" r="1.6"/><path d="M2 3h3l2.6 12.2a2 2 0 0 0 2 1.6h8.8a2 2 0 0 0 2-1.6L22 7H6"/>',
  pin: '<path d="M12 22s7-6.1 7-12a7 7 0 1 0-14 0c0 5.9 7 12 7 12Z"/><circle cx="12" cy="10" r="2.6"/>',
  phone: '<path d="M6.6 3h3l1.5 4-2 1.4a12 12 0 0 0 5.5 5.5l1.4-2 4 1.5v3A2 2 0 0 1 18 18.4C10.6 17.8 5.2 12.4 4.6 5A2 2 0 0 1 6.6 3Z"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5.4l3.4 2"/>',
  check: '<path d="M4 12.6 9.2 18 20 6.6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  ice: '<path d="M8 3.5h8L14 13v6.5a2 2 0 0 1-4 0V13L8 3.5Z"/><path d="M7.6 9.5h8.8"/>',
  cup: '<path d="M6 8h12l-1.2 11.2a2 2 0 0 1-2 1.8H9.2a2 2 0 0 1-2-1.8L6 8Z"/><path d="M8.4 4.5h7.2l.4 3.5H8l.4-3.5Z"/>',
  food: '<path d="M5 3v8a2 2 0 0 0 2 2v8M9 3v8a2 2 0 0 1-2 2M17 3c-1.6 1.4-2.4 3.4-2.4 5.6 0 1.6.6 2.6 1.6 3.4V21h2.4V3h-1.6Z"/>',
  arrow: '<path d="M5 12h13M13 6l6 6-6 6"/>',
  user: '<circle cx="12" cy="8.5" r="3.6"/><path d="M4.5 20a7.5 7.5 0 0 1 15 0"/>',
  lock: '<rect x="4.5" y="10.5" width="15" height="10" rx="2.4"/><path d="M8 10.5V8a4 4 0 0 1 8 0v2.5"/>',
  route: '<circle cx="6" cy="18" r="2.6"/><circle cx="18" cy="6" r="2.6"/><path d="M8.4 16.6c4-1.2 3.2-5.6 6.6-6.9"/>',
  truck: '<path d="M3 6.5h10v10H3z"/><path d="M13 9.5h4.2l3 3.2v3.8H13z"/><circle cx="7" cy="18.4" r="1.8"/><circle cx="17" cy="18.4" r="1.8"/>',
  share: '<path d="M12 15V4M8 7.5 12 3.5l4 4"/><path d="M5 13v6.5a1.5 1.5 0 0 0 1.5 1.5h11A1.5 1.5 0 0 0 19 19.5V13"/>',
  qr: '<rect x="3.5" y="3.5" width="7" height="7" rx="1.4"/><rect x="13.5" y="3.5" width="7" height="7" rx="1.4"/><rect x="3.5" y="13.5" width="7" height="7" rx="1.4"/><path d="M14 14h3v3h-3zM20.5 14v3M17.5 20.5h3M14 20.5h1"/>',
  trash: '<path d="M4.5 7h15M9 7V4.6h6V7M6 7l1 13h10l1-13"/>',
  edit: '<path d="M4 20h4l10-10-4-4L4 16v4Z"/><path d="M14.5 5.5 18.5 9.5"/>',
  logout: '<path d="M15 4.5h3.5A1.5 1.5 0 0 1 20 6v12a1.5 1.5 0 0 1-1.5 1.5H15"/><path d="M11 8 7 12l4 4M7 12h10"/>',
  alert: '<path d="M12 3.8 21 19.5H3L12 3.8Z"/><path d="M12 9.5v4.2M12 16.6v.1"/>',
  wifioff: '<path d="M3 5.5 19 21.5"/><path d="M5 10.5a12 12 0 0 1 5-2.4M19 10.5a12 12 0 0 0-3-1.9"/><path d="M8.5 14a7 7 0 0 1 2-.9M15.5 14.4c.5.3.9.6 1.3 1"/><circle cx="12" cy="18.6" r="1"/>',
  refresh: '<path d="M20 11a8 8 0 1 0-2.4 6.2"/><path d="M20 5v6h-6"/>',
  euro: '<path d="M17 6.5A6.5 6.5 0 1 0 17 17.5"/><path d="M4.5 10.5h9M4.5 14h9"/>',
  info: '<circle cx="12" cy="12" r="9"/><path d="M12 11v5.5M12 7.8v.1"/>',
  menu: '<path d="M4 7h16M4 12h16M4 17h16"/>',
  home: '<path d="M4 11 12 4l8 7v8.5a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19.5V11Z"/>',
  bell: '<path d="M6.5 17h11l-1.4-2.2V10a4.1 4.1 0 1 0-8.2 0v4.8L6.5 17Z"/><path d="M10 19.5a2 2 0 0 0 4 0"/>',
  chart: '<path d="M4 20V4"/><path d="M4 20h16"/><path d="M8 16v-5M12.5 16V7M17 16v-8"/>',
  sun: '<circle cx="12" cy="12" r="4"/><path d="M12 2.5v2.2M12 19.3v2.2M2.5 12h2.2M19.3 12h2.2M5.3 5.3l1.6 1.6M17.1 17.1l1.6 1.6M18.7 5.3l-1.6 1.6M6.9 17.1l-1.6 1.6"/>',
  image: '<rect x="3.5" y="5" width="17" height="14" rx="2"/><circle cx="9" cy="10.5" r="1.6"/><path d="M4.5 17.5 10 12l4 3.6 2.4-2.1 3.1 3"/>',
};

export function ic(name, cls = '') {
  const body = ICONS[name] || ICONS.info;
  return `<svg class="${cls}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;
}

/* ------------------------------------------------------------------ toasts */
export function toast(message, kind = '', ms = 3600) {
  const host = document.getElementById('toasts');
  if (!host) return;
  const el = document.createElement('div');
  el.className = `toast ${kind}`;
  el.textContent = message;
  host.appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; setTimeout(() => el.remove(), 300); }, ms);
}

/* ---------------------------------------------------------------- sheet UI */
const sheet = {
  el: null, scrim: null, titleEl: null, bodyEl: null, footEl: null,
  init() {
    this.el = document.getElementById('sheet');
    this.scrim = document.getElementById('scrim');
    this.titleEl = document.getElementById('sheetTitle');
    this.bodyEl = document.getElementById('sheetBody');
    this.footEl = document.getElementById('sheetFoot');
    document.getElementById('sheetClose').addEventListener('click', () => this.close());
    this.scrim.addEventListener('click', () => this.close());
    document.addEventListener('keydown', (e) => { if (e.key === 'Escape') this.close(); });
  },
  open({ title = '', body = '', foot = '', onMount } = {}) {
    this.titleEl.textContent = title;
    this.bodyEl.innerHTML = body;
    if (foot) { this.footEl.hidden = false; this.footEl.innerHTML = foot; }
    else { this.footEl.hidden = true; this.footEl.innerHTML = ''; }
    this.el.classList.add('open');
    this.scrim.classList.add('open');
    document.body.classList.add('no-scroll');
    if (onMount) onMount(this.bodyEl, this.footEl);
  },
  close() {
    this.el.classList.remove('open');
    this.scrim.classList.remove('open');
    document.body.classList.remove('no-scroll');
  },
};

export const ui = {
  sheet,
  setHeader({ visible = true } = {}) {
    document.getElementById('header').hidden = !visible;
    document.getElementById('footer').hidden = !visible;
  },
  loading(target, rows = 3) {
    target.innerHTML = `<div class="stack">${Array.from({ length: rows }, () => '<div class="skeleton"></div>').join('')}</div>`;
  },
  empty(target, { title = 'Rien à afficher', text = '', icon = 'info' } = {}) {
    target.innerHTML = `<div class="empty">${ic(icon)}<h3>${esc(title)}</h3><p class="small">${esc(text)}</p></div>`;
  },
  banner(kind, text, icon = 'info') {
    return `<div class="banner banner-${kind}">${ic(icon)}<div>${text}</div></div>`;
  },
};

/* -------------------------------------------------------------- navigation */
export function navigate(path, { replace = false } = {}) {
  if (replace) history.replaceState({}, '', path);
  else history.pushState({}, '', path);
  window.dispatchEvent(new PopStateEvent('popstate'));
}

/* ------------------------------------------------------------- géolocalisation */
/**
 * Demande la position au téléphone.
 *
 * Sur un téléphone posé sur le sable, la première mesure est souvent imprécise
 * (parfois à 1 km près) : on ne s'en contente pas. On interroge la position
 * plusieurs fois et on renvoie LA MEILLEURE pendant le temps imparti, ce qui
 * divise souvent l'erreur par 5 à 20. Le temps réel est renvoyé par `onProgress`
 * pour que l'écran puisse rassurer le client (« recherche… ±320 m »).
 *
 * @returns {Promise<{lat,lng,accuracy,at}>}
 */
export function getPosition({ timeout = 20000, highAccuracy = true, onProgress = null, attempts = 3 } = {}) {
  return new Promise((resolve, reject) => {
    if (!('geolocation' in navigator)) {
      const e = new Error('Ce navigateur ne fournit pas la position.');
      e.code = 0;
      reject(e);
      return;
    }
    if (!window.isSecureContext) {
      const e = new Error(
        'La localisation n\'est possible qu\'en HTTPS. Ouvrez le site avec une adresse commençant par https://, '
        + 'ou indiquez votre position à la main (le livreur vous appellera).',
      );
      e.code = 'INSECURE';
      reject(e);
      return;
    }

    const debut = Date.now();
    let meilleure = null;
    let watchId = null;
    let minuteur = null;
    let restants = attempts;

    const finir = (erreur) => {
      if (watchId !== null) { try { navigator.geolocation.clearWatch(watchId); } catch { /* ignore */ } watchId = null; }
      if (minuteur) { clearTimeout(minuteur); minuteur = null; }
      const ecoule = Date.now() - debut;
      if (meilleure && (!erreur || ecoule >= timeout || (meilleure.accuracy <= 60 && restants <= 0))) {
        resolve(meilleure);
        return;
      }
      if (meilleure) { resolve(meilleure); return; }
      const msg = {
        1: 'Position refusée. Autorisez la localisation pour ce site (icône à côté de l\'adresse), puis réessayez. Sinon, indiquez votre position à la main.',
        2: 'Position indisponible pour le moment (signal GPS faible). Sortez le téléphone de la poche, écartez-vous du parasol, puis réessayez.',
        3: 'La recherche de votre position a pris trop de temps. Réessayez, ou indiquez votre position à la main.',
      };
      const e2 = erreur instanceof Error ? erreur : new Error(msg[erreur?.code] || 'Position indisponible pour le moment.');
      if (erreur && !(erreur instanceof Error)) e2.code = erreur.code;
      reject(e2);
    };

    /** Enregistre la mesure si elle est meilleure que la précédente. */
    const retenir = (pos) => {
      const mesure = {
        lat: pos.coords.latitude,
        lng: pos.coords.longitude,
        accuracy: Math.round(pos.coords.accuracy || 0),
        at: pos.timestamp || Date.now(),
      };
      if (!meilleure || mesure.accuracy < meilleure.accuracy) meilleure = mesure;
      if (typeof onProgress === 'function') onProgress(meilleure);
      // Mesure franchement bonne : inutile d'insister.
      if (meilleure.accuracy <= 25) finir(null);
      return mesure;
    };

    try {
      watchId = navigator.geolocation.watchPosition(
        (pos) => {
          retenir(pos);
          restants -= 1;
          if (restants <= 0 && meilleure) finir(null);
        },
        (err) => finir(err),
        { enableHighAccuracy: highAccuracy, timeout, maximumAge: 0 },
      );
    } catch (err) {
      reject(new Error('Localisation indisponible sur cet appareil. Indiquez votre position à la main.'));
      return;
    }

    // Garde-fou : on rend la meilleure mesure au bout du temps imparti.
    minuteur = setTimeout(() => finir(null), timeout);
  });
}

export function watchPosition(onPos, onErr) {
  if (!('geolocation' in navigator)) return () => {};
  const id = navigator.geolocation.watchPosition(
    (pos) => onPos({
      lat: pos.coords.latitude, lng: pos.coords.longitude, accuracy: pos.coords.accuracy, at: pos.timestamp || Date.now(),
    }),
    (err) => onErr && onErr(err),
    { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 },
  );
  return () => navigator.geolocation.clearWatch(id);
}

/* --------------------------------------------------------------- temps réel
   Sur un hébergement mutualisé (Hostinger), les connexions permanentes ne sont
   pas fiables : on interroge l'API à intervalle court, en ne transmettant que
   les changements. L'interface reste identique à celle de la version Node :
   live(url, handlers) renvoie toujours une fonction d'arrêt.
   ------------------------------------------------------------------------- */
const POLL_MS = { track: 4000, courier: 5000, admin: 6000, public: 25000 };

export function live(url, handlers = {}) {
  let stopped = false;
  let timer = null;
  const fire = (name, data) => { try { handlers[name]?.(data); } catch (e) { console.error(e); } };
  const query = new URLSearchParams((url.split('?')[1] || ''));

  let interval = POLL_MS.public;
  let tick = async () => {};

  if (url.includes('/api/events/track')) {
    // --- suivi d'une commande par le client
    const token = query.get('t') || '';
    const orderId = new URLSearchParams(location.search).get('id') || '';
    let lastStatus = null;
    let lastPaid = null;
    let lastPosAt = 0;
    interval = POLL_MS.track;

    tick = async () => {
      if (!orderId || !token) return;
      const res = await api.get(`/api/orders/${encodeURIComponent(orderId)}?t=${encodeURIComponent(token)}`);
      const o = res.order;
      connection.online();
      if (lastStatus === null) { lastStatus = o.status; lastPaid = o.paymentStatus; }
      else if (o.status !== lastStatus || o.paymentStatus !== lastPaid) {
        lastStatus = o.status; lastPaid = o.paymentStatus;
        fire('order:update', { order: o });
      } else {
        fire('order:eta', { order: o });
      }
      const pos = o.courier && o.courier.position;
      if (pos && pos.at !== lastPosAt) {
        lastPosAt = pos.at;
        fire('courier:position', { ...pos, courierId: o.courier.id, name: o.courier.name, orderIds: [o.id] });
      }
    };

  } else if (url.includes('/api/events/courier')) {
    // --- espace livreur : nouvelles commandes assignées
    let lastRev = null;
    let known = new Set();
    interval = POLL_MS.courier;

    tick = async () => {
      const d = await api.get('/api/courier/dashboard');
      connection.online();
      const ids = d.orders.map((o) => o.id);
      const rev = JSON.stringify(d.orders.map((o) => [o.id, o.status, o.paymentStatus]));
      if (lastRev === null) { lastRev = rev; known = new Set(ids); return; }
      if (rev !== lastRev) {
        const fresh = ids.filter((id) => !known.has(id));
        lastRev = rev;
        known = new Set(ids);
        fire(fresh.length ? 'order:new' : 'order:update', { id: fresh[0] || null });
      }
    };

  } else if (url.includes('/api/events/admin')) {
    // --- tableau de bord administrateur
    let lastOrders = null;
    let lastPos = null;
    let lastMenu = null;
    let known = new Set();
    interval = POLL_MS.admin;

    tick = async () => {
      const st = await api.get('/api/admin/state');
      connection.online();
      const ids = st.orders.map((o) => o.id);
      const ordersRev = JSON.stringify(st.orders.map((o) => [o.id, o.status, o.paymentStatus, o.courierId]));
      const posRev = JSON.stringify(st.couriers.map((c) => [c.id, c.online, c.lastPos && c.lastPos.at]));
      const menuRev = JSON.stringify(st.products.map((p) => [p.id, p.price, p.available])) + JSON.stringify(st.settings);

      if (lastOrders === null) {
        lastOrders = ordersRev; lastPos = posRev; lastMenu = menuRev; known = new Set(ids);
        return;
      }
      if (ordersRev !== lastOrders) {
        const fresh = ids.filter((id) => !known.has(id));
        lastOrders = ordersRev;
        known = new Set(ids);
        fire(fresh.length ? 'order:new' : 'order:update', {});
      }
      if (posRev !== lastPos) {
        lastPos = posRev;
        const c = st.couriers.find((x) => x.lastPos);
        if (c) fire('courier:position', { ...c.lastPos, courierId: c.id, name: c.name });
      }
      if (menuRev !== lastMenu) {
        lastMenu = menuRev;
        fire('menu:update', {});
        fire('couriers:update', {});
      }
    };

  } else {
    // --- carte des produits : prévenir lorsque l'admin modifie un prix ou retire un article
    let lastRev = null;
    tick = async () => {
      const menu = await api.get('/api/menu');
      connection.online();
      if (lastRev === null) { lastRev = menu.updatedAt; return; }
      if (menu.updatedAt !== lastRev) { lastRev = menu.updatedAt; fire('menu:update', {}); }
    };
  }

  const loop = async () => {
    if (stopped) return;
    if (!document.hidden) {
      try { await tick(); } catch (err) { if (!err.offline) connection.online(); else connection.offline(); }
    }
    if (!stopped) timer = setTimeout(loop, interval);
  };
  timer = setTimeout(loop, interval);

  return () => { stopped = true; clearTimeout(timer); };
}

export const connection = {
  online$: true,
  timers: new Set(),
  onChange(fn) { this.timers.add(fn); },
  status(v) {
    if (this.online$ === v) return;
    this.online$ = v;
    const bar = document.getElementById('offlineBar');
    if (bar) bar.classList.toggle('show', !v);
    for (const fn of this.timers) fn(v);
  },
  online() { this.status(true); },
  offline() { this.status(false); },
};

window.addEventListener('online', () => connection.status(true));
window.addEventListener('offline', () => connection.status(false));

/* ------------------------------------------------------------------- utils */
export function debounce(fn, ms = 250) {
  let t; return (...a) => { clearTimeout(t); t = setTimeout(() => fn(...a), ms); };
}

/** Mémorise l'email utilisé pour pré-remplir le formulaire de reconnexion. */
export function rememberEmail(email) { if (email) LS.set(K.lastEmail, email); }
export function lastEmail() { return LS.get(K.lastEmail, ''); }

export function vibrate(pattern = 18) {
  try { navigator.vibrate?.(pattern); } catch { /* ignore */ }
}

export { LS };
export const avatar = (name) => (String(name || '?').trim()[0] || '?').toUpperCase();
